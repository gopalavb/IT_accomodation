

<?php
if($_GET['func'] == "drop_1" && isset($_GET['func'])) {
    drop_1($_GET['drop_var']);
}

function drop_1($drop_var)
{
    include('conn.php');
    
    
    echo"hello";
        
}
?>
