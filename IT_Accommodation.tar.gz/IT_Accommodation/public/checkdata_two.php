<?php
error_reporting(E_ERROR | E_PARSE);
include 'conn.php';


if(isset($_POST['date1']))
{
	
  $date=$_POST['date1'];
    

  $exp = explode("-",$date);
  $d1 = $exp[0];
  $m1 = $exp[1];
  $y = $exp[2];
  
  $date2 = "$y-$m1-$d1";
  

 
    $sql1 = "SELECT count(*) FROM `g_booking` WHERE ('$date2' BETWEEN ci_date AND co_date)";
    $result1 = $conn->prepare($sql1);
    $result1->execute();
    $number_of_rows1 = $result1->fetchColumn();
    if($number_of_rows1 > 0)
    {
        echo"No Rooms Available on $date";
    }
    else
    {

    }
   
  //echo"$date2";
    
 //echo"$exp_type,$cit_y,$labname_y";


/*    if($time == '00:00') {
        echo "$time,$date,$labname_y, slot is booked!!!";
    }
    else
    {

    }*/
 
 
 
} 


?>