<?php
error_reporting(E_ERROR | E_PARSE);


/* $host = 'localhost';
$user = 'root';
$pass = '';

mysql_connect($host, $user, $pass);

mysql_select_db('aosmith_exp'); */

include 'conn.php';


if(isset($_POST['date2']))
{

    echo"<div class=\"table-responsive\">";
    echo"<table class=\"table table-striped\">";
    echo"<tbody>";
    
    $date1=$_POST['date1'];
    $date2=$_POST['date2'];
    
    echo"<tr><td>Available</td><td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td><td>Booked</td><td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td></tr>";
    echo"<tr><td style='text-align:center;'>Date</td><td style='text-align:center;'>A01</td><td style='text-align:center;'>A02</td><td style='text-align:center;'>A03</td><td style='text-align:center;'>A04</td><td style='text-align:center;'>A21</td><td style='text-align:center;'>A22</td><td style='text-align:center;'>A23</td><td style='text-align:center;'>A24</td><td style='text-align:center;'>B21</td><td style='text-align:center;'>B22</td><td style='text-align:center;'>B23</td><td style='text-align:center;'>B24</td><td style='text-align:center;'>B31</td><td style='text-align:center;'>B32</td><td style='text-align:center;'>B33</td><td style='text-align:center;'>B34</td></tr>";
    
    $begin = new DateTime( $date1 );
    $end   = new DateTime( $date2 );
    
    for($i = $begin; $i <= $end; $i->modify('+1 day')){
        $check_date = $i->format("Y-m-d");
        echo"<tr><td>$check_date</td>";
        
        $sql_11 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A01%'";
        $result_11 = $conn->prepare($sql_11);
        $result_11->execute();
        $number_of_rows_11 = $result_11->fetchColumn();
        if($number_of_rows_11 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td  style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } 
        
        
        $sql_22 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A02%'";
        $result_22 = $conn->prepare($sql_22);
        $result_22->execute();
        $number_of_rows_22 = $result_22->fetchColumn();
        if($number_of_rows_22 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_33 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A03%'";
        $result_33 = $conn->prepare($sql_33);
        $result_33->execute();
        $number_of_rows_33 = $result_33->fetchColumn();
        if($number_of_rows_33 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_44 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A04%'";
        $result_44 = $conn->prepare($sql_44);
        $result_44->execute();
        $number_of_rows_44 = $result_44->fetchColumn();
        if($number_of_rows_44 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_55 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A21%'";
        $result_55 = $conn->prepare($sql_55);
        $result_55->execute();
        $number_of_rows_55 = $result_55->fetchColumn();
        if($number_of_rows_55 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_66 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A22%'";
        $result_66 = $conn->prepare($sql_66);
        $result_66->execute();
        $number_of_rows_66 = $result_66->fetchColumn();
        if($number_of_rows_66 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_77 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A23%'";
        $result_77 = $conn->prepare($sql_77);
        $result_77->execute();
        $number_of_rows_77 = $result_77->fetchColumn();
        if($number_of_rows_77 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_88 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A24%'";
        $result_88 = $conn->prepare($sql_88);
        $result_88->execute();
        $number_of_rows_88 = $result_88->fetchColumn();
        if($number_of_rows_88 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_99 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B21%'";
        $result_99 = $conn->prepare($sql_99);
        $result_99->execute();
        $number_of_rows_99 = $result_99->fetchColumn();
        if($number_of_rows_99 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_10 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B22%'";
        $result_10 = $conn->prepare($sql_10);
        $result_10->execute();
        $number_of_rows_10 = $result_10->fetchColumn();
        if($number_of_rows_10 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_111 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B23%'";
        $result_111 = $conn->prepare($sql_111);
        $result_111->execute();
        $number_of_rows_111 = $result_111->fetchColumn();
        if($number_of_rows_111 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_12 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B24%'";
        $result_12 = $conn->prepare($sql_12);
        $result_12->execute();
        $number_of_rows_12 = $result_12->fetchColumn();
        if($number_of_rows_12 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_13 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B31%'";
        $result_13 = $conn->prepare($sql_13);
        $result_13->execute();
        $number_of_rows_13 = $result_13->fetchColumn();
        if($number_of_rows_13 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_14 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B32%'";
        $result_14 = $conn->prepare($sql_14);
        $result_14->execute();
        $number_of_rows_14 = $result_14->fetchColumn();
        if($number_of_rows_14 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_15 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B33%'";
        $result_15 = $conn->prepare($sql_15);
        $result_15->execute();
        $number_of_rows_15 = $result_15->fetchColumn();
        if($number_of_rows_15 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_16 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B34%'";
        $result_16 = $conn->prepare($sql_16);
        $result_16->execute();
        $number_of_rows_16 = $result_16->fetchColumn();
        if($number_of_rows_16 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
       
        
        echo"<tr>";
    }
    //
    
     /*$sql1 = "SELECT count(*) FROM `lab_book` WHERE ('$date_time' BETWEEN fdate_ftime AND tdate_ttime) AND room_number like '%A01%'";
    $result1 = $conn->prepare($sql1);
    $result1->execute();
    $number_of_rows1 = $result1->fetchColumn();
    if($number_of_rows1 > 0)
    {
        echo"Lab Already <i class=\"fa fa-home fa-1x text-success\" ></i>".$time;
    }
    else
    {

    } */




    echo"</tbody>";
    echo"</table></div>";
?>
   

    
    
    
    

<?php 
}


?>