

<?php
if($_GET['func'] == "drop_1" && isset($_GET['func'])) {
    drop_1($_GET['drop_var']);
}

function drop_1($drop_var)
{
    include('conn.php');
    
    $equery = $conn->prepare("select distinct no_adult from room_select where no_of_room = '$drop_var'");
    $equery->execute();
    echo"<div class=\"row\">";
    echo"<div class='col-sm-6 form-group'>";
    echo"<label><font color='red'>*</font>No of Adults</label>";
    echo"<select name='no_adults' class='form-control' required>";
    echo "<option value=''>---Select---</option>";
    while ($erows = $equery->fetch())
    {
        $adult = $erows['no_adult'];
        
        echo "<option value='$adult'>$adult</option>";
    }
    echo " </select></div>";
    
    
    $equery = $conn->prepare("select distinct no_kids from room_select where no_of_room = '$drop_var'");
    $equery->execute();
    echo "<div class='col-sm-6 form-group'>";
    echo"<label>No of Kids</label>";
    echo"<select name='no_kids' class='form-control'>";
    echo "<option value=''>---Select---</option>";
    while ($erows = $equery->fetch())
    {
        $kids = $erows['no_kids'];
        echo "<option value='$kids'>$kids</option>";
    }
    echo " </select></div></div>";
        
}
?>
