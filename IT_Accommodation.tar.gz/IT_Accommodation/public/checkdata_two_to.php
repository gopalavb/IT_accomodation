<?php
error_reporting(E_ERROR | E_PARSE);


/* $host = 'localhost';
 $user = 'root';
 $pass = '';
 
 mysql_connect($host, $user, $pass);
 
 mysql_select_db('aosmith_exp'); */

include 'conn.php';


if(isset($_POST['date2']))
{
    
    echo"<div class=\"table-responsive\">";
    echo"<table class=\"table table-striped\">";
    echo"<tbody>";
    
    $date1=$_POST['date1'];
    $date2=$_POST['date2'];
    
    echo"<tr><td>Available</td><td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td><td>Booked</td><td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td></tr>";
    echo"<tr><td style='text-align:center;'>Date</td>";
    echo"<td style='text-align:center;'>A01</td>";
    echo"<td style='text-align:center;'>A02</td>";
    echo"<td style='text-align:center;'>A03</td>";
    echo"<td style='text-align:center;'>A04</td>";
    echo"<td style='text-align:center;'>A11</td>";
    echo"<td style='text-align:center;'>A12</td>";
    echo"<td style='text-align:center;'>A13</td>";
    echo"<td style='text-align:center;'>A14</td>";
    echo"<td style='text-align:center;'>A21</td>";
    echo"<td style='text-align:center;'>A22</td>";
    echo"<td style='text-align:center;'>A23</td>";
    echo"<td style='text-align:center;'>A24</td>";
    echo"<td style='text-align:center;'>A31</td>";
    echo"<td style='text-align:center;'>A32</td>";
    echo"<td style='text-align:center;'>A33</td>";
    echo"<td style='text-align:center;'>A34</td>";
    echo"<td style='text-align:center;'>B11</td>";
    echo"<td style='text-align:center;'>B12</td>";
    echo"<td style='text-align:center;'>B13</td>";
    echo"<td style='text-align:center;'>B14</td>";
    echo"<td style='text-align:center;'>B21</td>";
    echo"<td style='text-align:center;'>B22</td>";
    echo"<td style='text-align:center;'>B23</td>";
    echo"<td style='text-align:center;'>B24</td>";
    echo"<td style='text-align:center;'>B31</td>";
    echo"<td style='text-align:center;'>B32</td>";
    echo"<td style='text-align:center;'>B33</td>";
    echo"<td style='text-align:center;'>B34</td></tr>";
    
    $begin = new DateTime( $date1 );
    $end   = new DateTime( $date2 );
    
    for($i = $begin; $i <= $end; $i->modify('+1 day')){
        $check_date = $i->format("Y-m-d");
        echo"<tr><td>$check_date</td>";
        
        $sql_11 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date)  AND status='Approve' AND room_number like '%A01%'";
        $result_11 = $conn->prepare($sql_11);
        $result_11->execute();
        $number_of_rows_11 = $result_11->fetchColumn();
        if($number_of_rows_11 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td  style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        
        $sql_22 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A02%'";
        $result_22 = $conn->prepare($sql_22);
        $result_22->execute();
        $number_of_rows_22 = $result_22->fetchColumn();
        if($number_of_rows_22 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_33 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A03%'";
        $result_33 = $conn->prepare($sql_33);
        $result_33->execute();
        $number_of_rows_33 = $result_33->fetchColumn();
        if($number_of_rows_33 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_44 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A04%'";
        $result_44 = $conn->prepare($sql_44);
        $result_44->execute();
        $number_of_rows_44 = $result_44->fetchColumn();
        if($number_of_rows_44 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        /* $sql_55 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A11%'";
        $result_55 = $conn->prepare($sql_55);
        $result_55->execute();
        $number_of_rows_55 = $result_55->fetchColumn(); */
        //if($number_of_rows_55 > 0)
        //{
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
       /*  $sql_66 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A12%'";
        $result_66 = $conn->prepare($sql_66);
        $result_66->execute();
        $number_of_rows_66 = $result_66->fetchColumn();
        if($number_of_rows_66 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        /* }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_77 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A13%'";
        $result_77 = $conn->prepare($sql_77);
        $result_77->execute();
        $number_of_rows_77 = $result_77->fetchColumn();
        if($number_of_rows_77 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        /* }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_88 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A14%'";
        $result_88 = $conn->prepare($sql_88);
        $result_88->execute();
        $number_of_rows_88 = $result_88->fetchColumn();
        if($number_of_rows_88 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        $sql_99 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A21%'";
        $result_99 = $conn->prepare($sql_99);
        $result_99->execute();
        $number_of_rows_99 = $result_99->fetchColumn();
        if($number_of_rows_99 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_10 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A22%'";
        $result_10 = $conn->prepare($sql_10);
        $result_10->execute();
        $number_of_rows_10 = $result_10->fetchColumn();
        if($number_of_rows_10 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_111 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A23%'";
        $result_111 = $conn->prepare($sql_111);
        $result_111->execute();
        $number_of_rows_111 = $result_111->fetchColumn();
        if($number_of_rows_111 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_12 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A24%'";
        $result_12 = $conn->prepare($sql_12);
        $result_12->execute();
        $number_of_rows_12 = $result_12->fetchColumn();
        if($number_of_rows_12 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
       /*  $sql_13 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A31%'";
        $result_13 = $conn->prepare($sql_13);
        $result_13->execute();
        $number_of_rows_13 = $result_13->fetchColumn();
        if($number_of_rows_13 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
       /*  $sql_14 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A32%'";
        $result_14 = $conn->prepare($sql_14);
        $result_14->execute();
        $number_of_rows_14 = $result_14->fetchColumn();
        if($number_of_rows_14 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_15 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A33%'";
        $result_15 = $conn->prepare($sql_15);
        $result_15->execute();
        $number_of_rows_15 = $result_15->fetchColumn();
        if($number_of_rows_15 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        /* }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_16 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%A34%'";
        $result_16 = $conn->prepare($sql_16);
        $result_16->execute();
        $number_of_rows_16 = $result_16->fetchColumn();
        if($number_of_rows_16 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_17 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B11%'";
        $result_17 = $conn->prepare($sql_17);
        $result_17->execute();
        $number_of_rows_17 = $result_17->fetchColumn();
        if($number_of_rows_17 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
       /*  $sql_18 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B12%'";
        $result_18 = $conn->prepare($sql_18);
        $result_18->execute();
        $number_of_rows_18 = $result_18->fetchColumn();
        if($number_of_rows_18 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        /* }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        /* $sql_19 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B13%'";
        $result_19 = $conn->prepare($sql_19);
        $result_19->execute();
        $number_of_rows_19 = $result_19->fetchColumn();
        if($number_of_rows_19 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
       /*  $sql_20 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B14%'";
        $result_20 = $conn->prepare($sql_20);
        $result_20->execute();
        $number_of_rows_20 = $result_20->fetchColumn();
        if($number_of_rows_20 > 0)
        { */
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
       /*  }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        } */
        
        $sql_21 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B21%'";
        $result_21 = $conn->prepare($sql_21);
        $result_21->execute();
        $number_of_rows_21 = $result_21->fetchColumn();
        if($number_of_rows_21 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_22 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B22%'";
        $result_22 = $conn->prepare($sql_22);
        $result_22->execute();
        $number_of_rows_22 = $result_22->fetchColumn();
        if($number_of_rows_22 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_23 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B23%'";
        $result_23 = $conn->prepare($sql_23);
        $result_23->execute();
        $number_of_rows_23 = $result_23->fetchColumn();
        if($number_of_rows_23 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_24 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B24%'";
        $result_24 = $conn->prepare($sql_24);
        $result_24->execute();
        $number_of_rows_24 = $result_24->fetchColumn();
        if($number_of_rows_24 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_25 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B31%'";
        $result_25 = $conn->prepare($sql_25);
        $result_25->execute();
        $number_of_rows_25 = $result_25->fetchColumn();
        if($number_of_rows_25 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_26 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B32%'";
        $result_26 = $conn->prepare($sql_26);
        $result_26->execute();
        $number_of_rows_26 = $result_26->fetchColumn();
        if($number_of_rows_26 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_27 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B33%'";
        $result_27 = $conn->prepare($sql_27);
        $result_27->execute();
        $number_of_rows_27 = $result_27->fetchColumn();
        if($number_of_rows_27 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        $sql_28 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date) AND status='Approve' AND room_number like '%B34%'";
        $result_28 = $conn->prepare($sql_28);
        $result_28->execute();
        $number_of_rows_28 = $result_28->fetchColumn();
        if($number_of_rows_28 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
            echo"<td style='background-color: #77dd77; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        
        
        
        
        echo"<tr>";
    }
    //
    
    /*$sql1 = "SELECT count(*) FROM `lab_book` WHERE ('$date_time' BETWEEN fdate_ftime AND tdate_ttime) AND room_number like '%A01%'";
     $result1 = $conn->prepare($sql1);
     $result1->execute();
     $number_of_rows1 = $result1->fetchColumn();
     if($number_of_rows1 > 0)
     {
     echo"Lab Already <i class=\"fa fa-home fa-1x text-success\" ></i>".$time;
     }
     else
     {
     
     } */
    
    
    
    
    echo"</tbody>";
    echo"</table></div>";
    ?>
   

    
    
    
    

<?php 
}


?>