<?php
error_reporting(E_ERROR | E_PARSE);


/* $host = 'localhost';
 $user = 'root';
 $pass = '';
 
 mysql_connect($host, $user, $pass);
 
 mysql_select_db('aosmith_exp'); */

include 'conn.php';


if(isset($_POST['date2']))
{
    
   
    
    $date11=$_POST['date1'];
    $date22=$_POST['date2'];
    
    
    $exp1 = explode("-", $date11);
    $d1 = $exp1[0];
    $m1 = $exp1[1];
    $y1 = $exp1[2];
    
    $date_mer1 = "$y1-$m1-$d1";
    
    $exp2 = explode("-", $date22);
    $d2 = $exp2[0];
    $m2 = $exp2[1];
    $y2 = $exp2[2];
    
    $date_mer2 = "$y2-$m2-$d2";
    
    
    function dateDiffInDays($date1, $date2)
    {
        $diff = strtotime($date2) - strtotime($date1);
        return abs(round($diff / 86400));
    }
    // Start date
    $date1 = $date_mer1;
    // End date
    $date2 = $date_mer2;
    // Function call to find date difference
    $dateDiff = dateDiffInDays($date1, $date2);
    
     if($dateDiff >= 6)
    {
        echo"<div class=\"table-responsive\">";
        echo"<table class=\"table table-striped\">";
        echo"<tbody>";
   echo"<td style='color: red; text-align:center;'>Check-in Date & Check-out Date should be less than or equal to 5 days</td>";
   echo"</tbody>";
   echo"</table></div>";
   
    }
    else
    {
        //echo"$dateDiff";
        if (strtotime($date_mer1) > strtotime($date_mer2)) {
            #$date occurs in the future
            //echo"grater";
            echo"<div class=\"table-responsive\">";
            echo"<table class=\"table table-striped\">";
            echo"<tbody>";
            echo"<td style='color: red; text-align:center;'>Check-out Date should be grater than Check-in Date</td>";
            echo"</tbody>";
            echo"</table></div>";
            
        } else {
            #$date occurs now or in the past
        }
    } 
     
    //echo"$dateDiff";
   
     
     /* $sql_11 = "SELECT count(*) FROM `g_booking` WHERE ('$check_date' BETWEEN ci_date AND co_date)  AND status='Approve' AND room_number like '%A01%'";
        $result_11 = $conn->prepare($sql_11);
        $result_11->execute();
        $number_of_rows_11 = $result_11->fetchColumn();
        if($number_of_rows_11 > 0)
        {
            echo"<td style='background-color: #ff6961; text-align:center;'><i class=\"fa fa-home fa-1x text-success\" ></i></td>";
        }
        else
        {
           
        } */
        
       
    
    
    
   
}
    ?>
   

    
    
    