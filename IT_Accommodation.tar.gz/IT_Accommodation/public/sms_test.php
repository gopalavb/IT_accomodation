<?php 

$contact = "918892022172";
$content = "Test Message";


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
curl_setopt($curl, CURLOPT_POST, 1);
//$str = http_build_query($arr);
curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
echo curl_error($curl);
$result =json_decode($result);
print_r($result);
curl_close($curl);

?>