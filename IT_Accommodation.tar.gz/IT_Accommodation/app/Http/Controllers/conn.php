
<?php
error_reporting(E_ERROR | E_PARSE);
$host = "localhost";
$username = "itacc_use";
$password = "ItA!Cc5@L1N19";
$dbname = "it_accommodation";
try
{
$conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
die(var_dump($e));
$message = 'database is not connected';
}
?>

