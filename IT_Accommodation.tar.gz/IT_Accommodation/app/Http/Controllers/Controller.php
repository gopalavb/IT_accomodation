<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;


use DB;
use Session;
use View;
use Hash;
use Auth;
use Excel;
use Mail;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    
    public function gbpublic(Request $req)
    {
        //return view('search_update_emp');
        //echo"hello add emp";
        $city = $req->input('city');
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        //$no_guest = $req->input('no_guest');
        $no_rooms = $req->input('no_rooms');
        $t_name = $req->input('t_name');
        $emp_id = $req->input('emp_id');
        $civil_id = $req->input('civil_id');
        $email_id = $req->input('email_id');
        $mobile_no = $req->input('mobile_no');
        $id_proof = $req->input('id_proof');
        $id_number = $req->input('id_number');
        $off_pri = $req->input('off_pri');
        
        $designation = $req->input('designation');
        
        $no_adults = $req->input('no_adults');
        $no_kids = $req->input('no_kids');
        
        $fromtime = $req->input('fromtime');
        $totime = $req->input('totime');
        
        $no_guest = $no_adults+$no_kids;
        
        $se_ob = $req->input('sel_obh');
        $self_half_text = $req->input('self_half_text');
        //$ = $req->input('');
        date_default_timezone_set("Asia/Kolkata");
        $date_tim = date("Y-m-d h:i:s");
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        $yea_mon = "$year1-$month1";
        
        function dateDiffInDays($date1, $date2)
        {
            $diff = strtotime($date2) - strtotime($date1);
            return abs(round($diff / 86400));
        }
        // Start date
        $date1 = $ci_date1;
        // End date
        $date2 = $co_date1;
        // Function call to find date difference
        $dateDiff = dateDiffInDays($date1, $date2);
        
        
        
        include'conn.php';
        
        //$sql_que = "SELECT count(*) FROM `g_booking` emp_id='$emp_id' AND DATE_FORMAT(`ci_date`, "%Y-%m") = '$yea_mon'";
        
        $sql_que = "SELECT count(*) FROM `g_booking` where emp_id='$emp_id' AND YEAR(ci_date) = '$year1' AND MONTH(ci_date) = '$month1'";
        $result_co = $conn->prepare($sql_que);
        $result_co->execute();
        $number_of_rows = $result_co->fetchColumn(); 
        
        
        
        
        $u_images=array();
        if($files=$req->file('upload_file')){
            foreach($files as $file){
                $name1=$file->getClientOriginalName();
                $destinationPath = public_path('/attachment');
                $file->move($destinationPath,$name1);
                $u_images[]=$name1;
            }
        }
        else
        {
            //$name1='';
            $u_images[]='';
        }
        
        
        if($dateDiff <= 5)
        {
            
            if($number_of_rows <= 1)
            {
                
                
                if (strtotime($ci_date1) > strtotime($co_date1)) {
                
                    return Redirect::to('gb')->withMessage('Check-out Date should be grater than Check-in Date');
                }
                else{
                
                
                        $data1 = array(
                            'city'=>$city,
                            'ci_date'=>$ci_date1,
                            'co_date'=>$co_date1,
                            'no_guest'=>$no_guest,
                            'no_rooms'=>$no_rooms,
                            't_name'=>$t_name,
                            'emp_id'=>$emp_id,
                            'civil_id'=>$civil_id,
                            'email_id'=>$email_id,
                            'mobile_no'=>$mobile_no,
                            'id_proof'=>$id_proof,
                            'id_number'=>$id_number,
                            'off_pri'=>$off_pri,
                            'path'=>implode("|",$u_images),
                            'booked_date_time'=>$date_tim,
                            'sel_obh'=>$se_ob,
                            'self_half_text'=>$self_half_text,
                            'adults'=>$no_adults,
                            'kids'=>$no_kids,
                            'designation'=>$designation,
                            'ci_time'=>$fromtime,
                            'co_time'=>$totime,
                            
                        );
                        DB::table('g_booking')->insert($data1);
                        
                        
                     /*    $body2 = "Dear $t_name, <br>";
                        $body2 .= "<br>";
                        $body2 .= "We have received your guest house booking request, responsible team will get back you immediately.<br>";
                        $body2 .= "Please find your booking details below.<br>";
                        $body2 .= "<html><body><table border='1px' width='400px'>";
                        $body2 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
                        $body2 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
                        $body2 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
                        $body2 .= "<tr><td><b>No of Guest's</b></td><td>Adults $no_adults, Kids $no_kids</td></tr>";
                        $body2 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
                        $body2 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
                        $body2 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
                        $body2 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
                        $body2 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
                        $body2 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
                        $body2 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
                        $body2 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
                        $body2 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
                        $body2 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
                        $body2 .= "</table></body></html>";
                        $body2 .= "<br>";
                        $body2 .= "\r\nSincerely,\r\n";
                        $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
                        Mail::raw($body2, function($message) use ($email_id, $body2)
                        {
                            $message->to($email_id)->subject('Guest House Booking');
                            $message->setBody($body2, 'text/html');
                        });
                       


			$contact = "91$mobile_no";
			$content = "Dear $t_name, We have received your guest house booking request, responsible team will get back you immediately. Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime";


			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
			curl_setopt($curl, CURLOPT_POST, 1);
			//$str = http_build_query($arr);
			curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			$result = curl_exec($curl);
			echo curl_error($curl);
			$result =json_decode($result);
			print_r($result);
			curl_close($curl);


 
                        
                        //$admin_email = "gopalkrishna_b@lintechnokrats.com";
                        $admin_email = "ito.hq.protocol@incometax.gov.in";
                        
                        $body1 = "Dear Admin, <br><br>";
                        $body1 .= "New guest house booking request, Please find the details below<br><br>";
                        $body1 .= "<html><body><table border='1px' width='400px'>";
                        $body1 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
                        $body1 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
                        $body1 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
                        $body1 .= "<tr><td><b>No of Guest's</b></td><td>Adults $no_adults, Kids $no_kids</td></tr>";
                        $body1 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
                        $body1 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
                        $body1 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
                        $body1 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
                        $body1 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
                        $body1 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
                        $body1 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
                        $body1 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
                        $body1 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
                        $body1 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
                        $body1 .= "</table></body></html>";
                        $body1 .= "<br>";
                        $body1 .= "\r\nSincerely,<br>";
                        $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
                        Mail::raw($body1, function($message) use ($admin_email, $body1)
                        {
                            $message->to($admin_email)->subject('Guest House Booking');
                            $message->setBody($body1, 'text/html');
                        }); 


                        $contact = "918892022172";
                        $content = "Dear Admin, New guest house booking request, Please find the details below. Traveller Name: $t_name, No of Guests: $no_adults,$no_kids,No of Rooms:$no_rooms,Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime";


                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);




*/
                        
                        //return Redirect::to('gb')->withMessage('Uploaded successfully');

			 notify()->success('Uploaded successfully');

		        return Redirect::to('gb');
                }
                        
            }
            else
            {
                return Redirect::to('gb')->withMessage('Guest House can be booked only 2 times in a month');
            }
        
        }
        else
        {
            return Redirect::to('gb')->withMessage('Check-in Date & Check-out Date should be less than 5 days');
        }
        
    } 
    
    
    public function gb_publicsecond(Request $req)
    {
        return Redirect::to('gb');
    }
    
}
