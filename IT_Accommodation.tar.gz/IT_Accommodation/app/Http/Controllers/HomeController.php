<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;


use DB;
use Session;
use View;
use Hash;
use Auth;
use Excel;
use Mail;
//use PDF;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    
  /*   public function gb_pub()
    {
        return view('gb');
        //echo"hello";
    } */
    
    public function gbapp_rej()
    {
        return view('gb_app_rej');
        //echo"hello";
    }
    
    public function corecgen_view()
    {
        return view('corec_gen_view');
        //echo"hello";
    }
    
    public function Referralbooking()
    {
        return view('Referral_booking');
        //echo"hello";
    }
    public function roomitems()
    {
        return view('room_items');
        //echo"hello";
    }
    
    public function roomitemupdate_view()
    {
        return view('roomitem_update_view');
        //echo"hello";
    }
    public function receiptview()
    {
        return view('receipt_view');
        //echo"hello";
    }
    public function managerreports()
    {
        return view('manager_reports');
        //echo"hello";
    }
    public function managerreports_view()
    {
        return view('manager_reports_view');
        //echo"hello";
    }
    
    public function receipt_viewfirst()
    {
        return view('receipt_view_first');
        //echo"hello";
    }
    
    
    
    
    

    
    
    public function gbview($id)
    {
        //echo"$id";
        return view('gb_app_rej', compact('id'));
    }

    public function gbapprej_adm(Request $req)
    {
        $city = $req->input('city');
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        //$no_guest = $req->input('no_guest');
        $no_rooms = $req->input('no_rooms');
        $t_name = $req->input('t_name');
        $emp_id = $req->input('emp_id');
        $civil_id = $req->input('civil_id');
        $email_id = $req->input('email_id');
        $mobile_no = $req->input('mobile_no');
        $id_proof = $req->input('id_proof');
        $id_number = $req->input('id_number');
        $off_pri = $req->input('off_pri');
        $remarks = $req->input('remarks');
        
        $no_adults = $req->input('no_adults');
        $no_kids = $req->input('no_kids');
        
        $Approve = $req->input('Approve');
        $Reject = $req->input('Reject');
        
        
        $room_type = $req->input('room_type');
        $room_number = $req->input('room_number');
        
        $designation = $req->input('designation');
        $fromtime = $req->input('fromtime');
        $totime = $req->input('totime');
        
        
        if($Approve == "Approve")
        {
            $ap_rej = "Approve";
        }
        else if($Reject == "Reject")
        {
            $ap_rej = "Reject";
        }
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        $u_images=array();
        if($files=$req->file('upload_file')){
            foreach($files as $file){
                $name1=$file->getClientOriginalName();
                $destinationPath = public_path('/attachment');
                $file->move($destinationPath,$name1);
                $u_images[]=$name1;
            }
        }
        else
        {
            //$name1='';
            $u_images[]='';
        }
        
        $id = $req->input('id');
        $path_names = $req->input('path_names');
        
        $new_fil = implode("|",$u_images);
        $upath_merge = "$path_names|$new_fil";
        $admin_email = Auth::user()->email;
        date_default_timezone_set("Asia/Kolkata");
        $date_tim = date("Y-m-d h:i:s");
        
           
            DB::table('g_booking')
            ->where('id',$req->id)
            ->update([
                'city'=>$city,
                'ci_date'=>$ci_date1,
                'co_date'=>$co_date1,
                //'no_guest'=>$no_guest,
                'no_rooms'=>$no_rooms,
                't_name'=>$t_name,
                'emp_id'=>$emp_id,
                'civil_id'=>$civil_id,
                'email_id'=>$email_id,
                'mobile_no'=>$mobile_no,
                'id_proof'=>$id_proof,
                'id_number'=>$id_number,
                'off_pri'=>$off_pri,
                'path'=>$upath_merge,
                'remarks'=>$remarks,
                'admin_update_date_time'=>$date_tim,
                'admin_id'=>$admin_email,
                'adults'=>$no_adults,
                'kids'=>$no_kids,
                'status'=>$ap_rej,
                'room_type'=>implode("|",$room_type),
                'room_number'=>implode("|",$room_number),
                'ci_time'=>$fromtime,
                'co_time'=>$totime,
                'designation'=>$designation,
            ]);
            
            
                 $rt = implode("|",$room_type);
                 $rn = implode("|",$room_number);
         
            /*
             $body2 = "Dear $t_name, <br>";
            $body2 .= "<br>";
            $body2 .= "Admin has $ap_rej your guest house booking request.<br>";
            $body2 .= "Please find your booking details below.<br>";
            $body2 .= "<html><body><table border='1px' width='400px'>";
            $body2 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
            $body2 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
            $body2 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
            $body2 .= "<tr><td><b>No of Guest's</b></td><td>Adults $no_adults, Kids $no_kids</td></tr>";
            $body2 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
	
	if($Approve == "Approve")
        {	
            $body2 .= "<tr><td><b>Room Type</b></td><td>$rt</td></tr>";
            $body2 .= "<tr><td><b>Room Number</b></td><td>$rn</td></tr>";
	}
	else if($Reject == "Reject")
	{

	}	

            $body2 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
            $body2 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
            $body2 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
            $body2 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
            $body2 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
            $body2 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
            $body2 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
            $body2 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
            $body2 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
            $body2 .= "<tr><td><b>Admin Remarks</b></td><td>$remarks</td></tr>";
            $body2 .= "<tr><td><b>Note:</b></td><td>Please carry a valid govt. issued address ID proof.</td></tr>";
            $body2 .= "</table></body></html>";
            
            
            $body2 .= "<br>";
            $body2 .= "\r\nSincerely,\r\n";
            $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
            Mail::raw($body2, function($message) use ($email_id, $body2)
            {
                $message->to($email_id)->subject('Guest House Booking');
                $message->setBody($body2, 'text/html');
            });

                        $contact = "91$mobile_no";
			if($Approve == "Approve")
        		{
                        $content = "Dear $t_name, Admin has $ap_rej your guest house booking request, Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime, Room Type:$rt,Room Number: $rn";
			 else if($Reject == "Reject")
        		{
			$content = "Dear $t_name, Admin has $ap_rej your guest house booking request, Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime";
			}

                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);


            
            //$admin_email = "gopalkrishna_b@lintechnokrats.com";
                        $admin_email = "ito.hq.protocol@incometax.gov.in";
            
            $body1 = "Dear Admin, <br><br>";
            $body1 .= "You have $ap_rej guest house booking request, Please find the details below<br><br>";
            $body1 .= "<html><body><table border='1px' width='400px'>";
            $body1 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
            $body1 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
            $body1 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
            $body1 .= "<tr><td><b>No of Guest's</b></td><td>Adults $no_adults, Kids $no_kids</td></tr>";
            $body1 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
            $body1 .= "<tr><td><b>Room Type</b></td><td>$rt</td></tr>";
            $body1 .= "<tr><td><b>Room Number</b></td><td>$rn</td></tr>";
            $body1 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
            $body1 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
            $body1 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
            $body1 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
            $body1 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
            $body1 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
            $body1 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
            $body1 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
            $body1 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
            $body1 .= "<tr><td><b>Remarks</b></td><td>$remarks</td></tr>";
            $body1 .= "</table></body></html>";
            $body1 .= "<br>";
            $body1 .= "\r\nSincerely,<br>";
            $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
            Mail::raw($body1, function($message) use ($admin_email, $body1)
            {
                $message->to($admin_email)->subject('Guest House Booking');
                $message->setBody($body1, 'text/html');
            }); 

                        $contact = "918892022172";
                        if($Approve == "Approve")
                        {
                        $content = "Dear Admin, you have $ap_rej guest house booking request, Traveller Name:$t_name, Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime, Room Type:$rt,Room Number: $rn";
                         else if($Reject == "Reject")
                        {
                        $content = "Dear Admin, you have $ap_rej guest house booking request, Traveller Name:$t_name, Check-in Date & time: $ci_date $fromtime, Check-out Date & time: $co_date $totime";
                        }

                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);


*/
            
            if($Approve == "Approve")
            {
                //$ap_rej = "Approve";
                return Redirect::to('home')->withMessage('Guest House Booking Approved successfully');
            }
            else if($Reject == "Reject")
            {
                //$ap_rej = "Reject";
                return Redirect::to('home')->withMessage('Guest House Booking Rejected successfully');
            }
            
    }
    
    
    public function managerhome()
    {
        return view('manager_home');
        //echo"hello";
    }
    
    public function gbviewmanager_cico()
    {
        return view('gbview_manager_cico');
    }
    
    public function gbview_manager($id)
    {
        //echo"$id";
        return view('gbview_manager_cico', compact('id'));
    }
    
    public function gbcico_mgr(Request $req)
    {
        $datas = $req->input('imagedatas');
        $filename =  time() . '.png';
        $filepath = './profiles/';
        $ndatas = explode(',',$datas);
        file_put_contents($filepath.$filename, base64_decode($ndatas[1]));
        
        echo"$filename";
        $id = $req->input('id');
        $adults = $req->input('adults');
        $kids = $req->input('kids');
        $no_guest = $req->input('no_guest');
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        $room_number = $req->input('room_number');
        $email_id = $req->input('email_id');
        $civil_id = $req->input('civil_id');
        $no_rooms = $req->input('no_rooms');
        $id_proof = $req->input('id_proof');
        $id_number = $req->input('id_number');
        $off_pri = $req->input('off_pri');
        $remarks = $req->input('remarks');
        $t_name = $req->input('t_name');
        
        $emp_id = $req->input('emp_id');
        $mobile_no = $req->input('mobile_no');
        $room_type = $req->input('room_type');
        $type_accomm = $req->input('type_accomm');
        $designation = $req->input('designation');
        
        $fromtime = $req->input('fromtime');
        $totime = $req->input('totime');
        //upload_file
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        
        
        
        $u_images=array();
        if($files=$req->file('upload_file')){
            foreach($files as $file){
                $name1=$file->getClientOriginalName();
                $destinationPath = public_path('/attachment');
                $file->move($destinationPath,$name1);
                $u_images[]=$name1;
            }
        }
        else
        {
            //$name1='';
            $u_images[]='';
        }
        
        date_default_timezone_set("Asia/Kolkata");
        $date_tim = date("Y-m-d h:i:s");
        $date_check = date("Y-m-d");
        
        if($ci_date1 == $date_check)
        {
        $data1 = array(
            'id_booking'=>$id,
            'adults'=>$adults,
            'kids'=>$kids,
            'no_guest'=>$no_guest,
            'ci_date'=>$ci_date1,
            'co_date'=>$co_date1,
            'room_no'=>implode("|",$room_number),
            'no_rooms'=>$no_rooms,
            'name'=>implode("|",$t_name),
            'email_id'=>$email_id,
            'civil_id'=>$civil_id,
            'id_proof'=>$id_proof,
            'id_number'=>$id_number,
            'off_pri'=>$off_pri,
            'path'=>implode("|",$u_images),
            'photo'=>$filename,
            'remarks'=>$remarks,
            'sub_date_time'=>$date_tim,
            'emp_id'=>$emp_id,
            'mobile_no'=>$mobile_no,
            'room_type'=>implode("|",$room_type),
            'type_accomm'=>$type_accomm,
            'designation'=>$designation,
            'ci_time'=>$fromtime,
            'co_time'=>$totime,
        );
        DB::table('g_booking_manager')->insert($data1);
        
        
        $rn= implode("|",$room_number);
        
        $rt = implode("|",$room_type);
        
        $exp_rt = explode("|", $rt);
        
        $exp_rt1 = $exp_rt[0];
        $exp_rt2 = $exp_rt[1];
        
        $query1="Select type_of_accd from amount_service where id='$exp_rt1'";
        $stmt1= $conn->query($query1);
        while($row1 = $stmt1->fetch())
        {
            $type_of_accd1 = $row1['type_of_accd'];
        }
        
        $query2="Select type_of_accd from amount_service where id='$exp_rt2'";
        $stmt2= $conn->query($query2);
        while($row2 = $stmt2->fetch())
        {
            $type_of_accd2 = $row2['type_of_accd'];
        }
        
        
        /*  $body2 = "Dear $t_name, <br>";
         $body2 .= "<br>";
         $body2 .= "Thank you, you have Checke-IN on $ci_date $fromtime.<br>";
         
          $body2 .= "Please find your booking details below.<br>";
         $body2 .= "<html><body><table border='1px' width='400px'>";
         $body2 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
         $body2 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
         $body2 .= "<tr><td><b>No of Guest's</b></td><td>Adults $adults, Kids $kids</td></tr>";
         $body2 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
         $body2 .= "<tr><td><b>Room Type</b></td><td>$type_of_accd1,$type_of_accd2</td></tr>";
         $body2 .= "<tr><td><b>Room Number</b></td><td>$rn</td></tr>";
         $body2 .= "<tr><td><b>Accommodation Type</b></td><td>$type_accomm</td></tr>";
         $body2 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
         $body2 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
         $body2 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
         $body2 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
         $body2 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
         $body2 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
         $body2 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
         $body2 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
         $body2 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
         $body2 .= "<tr><td><b>Admin Remarks</b></td><td>$remarks</td></tr>"; 
         $body2 .= "<tr><td><b>Note:</b></td><td>Please carry a valid govt. issued address ID proof.</td></tr>";
         $body2 .= "</table></body></html>";
         
         
         $body2 .= "<br>";
         $body2 .= "\r\nSincerely,\r\n";
         $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body2, function($message) use ($email_id, $body2)
         {
         $message->to($email_id)->subject('Guest House Booking Checke-IN');
         $message->setBody($body2, 'text/html');
         });

                        $contact = "91$mobile_no";
                        $content = "Dear $t_name, Thank you, you have Checke-IN on $ci_date $fromtime,Room Type:$type_of_accd1,$type_of_accd2,Room Number:$rn";


                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);        
 
         //$admin_email = "gopalkrishna_b@lintechnokrats.com";
         $admin_email = "ito.hq.protocol@incometax.gov.in";
         
         $body1 = "Dear Admin, <br><br>";
         $body1 .= "Manager has Checke-IN for guest $t_name, Please find the details below<br><br>";
         $body1 .= "<html><body><table border='1px' width='400px'>";
         $body1 .= "<tr><td><b>Check-in Date & time</b></td><td>$ci_date $fromtime</td></tr>";
         $body1 .= "<tr><td><b>Check-out Date & time</b></td><td>$co_date $totime</td></tr>";
         $body1 .= "<tr><td><b>No of Guest's</b></td><td>Adults $adults, Kids $kids</td></tr>";
         $body1 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
         $body1 .= "<tr><td><b>Room Type</b></td><td>$type_of_accd1,$type_of_accd2</td></tr>";
         $body1 .= "<tr><td><b>Room Number</b></td><td>$rn</td></tr>";
         $body1 .= "<tr><td><b>Accommodation Type</b></td><td>$type_accomm</td></tr>";
         $body1 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
         $body1 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
         $body1 .= "<tr><td><b>Designation</b></td><td>$designation</td></tr>";
         $body1 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
         $body1 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
         $body1 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
         $body1 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
         $body1 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
         $body1 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
         $body1 .= "<tr><td><b>Remarks</b></td><td>$remarks</td></tr>";
         $body1 .= "</table></body></html>";
         $body1 .= "<br>";
         $body1 .= "\r\nSincerely,<br>";
         $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body1, function($message) use ($admin_email, $body1)
         {
         $message->to($admin_email)->subject('Guest House Booking Checke-IN');
         $message->setBody($body1, 'text/html');
         }); 

			$contact = "918892022172";
                        $content = "Dear Admin, Manager has Checke-IN for guest $t_name, Checke-IN on $ci_date $fromtime,Room Type:$type_of_accd1,$type_of_accd2,Room Number:$rn";


                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);


*/ 
       
        return Redirect::to('home')->withMessage('Check-in successfully');
        }
        else
        {
            return Redirect::to('home')->withMessage("Check-in should be done on $ci_date");
        }
        
    }
    
    
    public function corec_gen($id)
    {
        //echo"$id";
        return view('corec_gen_view', compact('id'));
    }
    
    
    
    public function reffbook(Request $req)
    {
        
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        $t_name = $req->input('t_name');
        $reffer_by = $req->input('reffer_by');
        $mobile_no = $req->input('mobile_no');
        $remarks = $req->input('remarks');
        $off_pri = $req->input('off_pri');
        $room_type = $req->input('room_type');
        $room_number = $req->input('room_number');
        
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        $u_images=array();
        if($files=$req->file('upload_file')){
            foreach($files as $file){
                $name1=$file->getClientOriginalName();
                $destinationPath = public_path('/attachment');
                $file->move($destinationPath,$name1);
                $u_images[]=$name1;
            }
        }
        else
        {
            //$name1='';
            $u_images[]='';
        }
        
        date_default_timezone_set("Asia/Kolkata");
        $date_tim = date("Y-m-d h:i:s");
        $status = "Approve";
        $rooms = 1;
	$adult = 1;
        $data1 = array(
            'ci_date'=>$ci_date1,
            'co_date'=>$co_date1,
            't_name'=>$t_name,
            'reffer_by'=>$reffer_by,
            'remarks'=>$remarks,
            'mobile_no'=>$mobile_no,
            'booked_date_time'=>$date_tim,
            'status'=>$status,
            'no_rooms'=>$rooms,
            'path'=>implode("|",$u_images),
            'off_pri'=>$off_pri,
            'room_type'=>$room_type,
            'room_number'=>$room_number,
            'adults'=>$adult,
            
        );
        DB::table('g_booking')->insert($data1);
       

 /*    $body2 = "Dear $t_name, <br>";
                        $body2 .= "<br>";
                        $body2 .= "We have received your Referral guest house booking request, responsible team will get back you immediately.<br>";
                        $body2 .= "Please find your booking details below.<br>";
                        $body2 .= "<html><body><table border='1px' width='400px'>";
                        $body2 .= "<tr><td><b>Check-in Date</b></td><td>$ci_date</td></tr>";
                        $body2 .= "<tr><td><b>Check-out Date</b></td><td>$co_date</td></tr>";
                        $body2 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
                        $body2 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
                        $body2 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
                        $body2 .= "</table></body></html>";
                        $body2 .= "<br>";
                        $body2 .= "\r\nSincerely,\r\n";
                        $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
                        Mail::raw($body2, function($message) use ($email_id, $body2)
                        {
                            $message->to($email_id)->subject('Referral Guest House Booking');
                            $message->setBody($body2, 'text/html');
                        });

 $contact = "91$mobile_no";
                        $content = "Dear $t_name, We have received your Referral guest house booking request, responsible team will get back you immediately. Check-in Date & time: $ci_date, Check-out Date & time: $co_date";


                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);


    //$admin_email = "gopalkrishna_b@lintechnokrats.com";
                        $admin_email = "ito.hq.protocol@incometax.gov.in";

                        $body1 = "Dear Admin, <br><br>";
                        $body1 .= "New Referral guest house booking request, Please find the details below<br><br>";
			$body1 .= "<html><body><table border='1px' width='400px'>";
                        $body1 .= "<tr><td><b>Check-in Date</b></td><td>$ci_date</td></tr>";
                        $body1 .= "<tr><td><b>Check-out Date</b></td><td>$co_date</td></tr>";
                        $body1 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
                        $body1 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
                        $body1 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
                        $body1 .= "</table></body></html>";
                        $body1 .= "<br>";
                        $body1 .= "\r\nSincerely,<br>";
                        $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
                        Mail::raw($body1, function($message) use ($admin_email, $body1)
                        {
                            $message->to($admin_email)->subject('Referral Guest House Booking');
                            $message->setBody($body1, 'text/html');
                        });



      $contact = "918892022172";
                        $content = "Dear Admin, New Referral guest house booking request, Please find the details below. Traveller Name: $t_name,Check-in Date: $ci_date $fromtime, Check-out Date: $co_date";


                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);
*/



 
        return Redirect::to('home')->withMessage('Referral Booking Done Successfully');
        
    }
    
    public function additem(Request $req)
    {
        
        $name = $req->input('name');
        $amount = $req->input('amount');
    
        $data1 = array(
            'name'=>$name,
            'amount'=>$amount,
        );
        DB::table('room_item')->insert($data1);
        
        return Redirect::to('room_items')->withMessage('Item Uploaded Successfully');
    
    }
    
    
    public function roomitem_update($id)
    {
        //echo"$id";
        return view('roomitem_update_view', compact('id'));
    }
    
    
    public function updateitem(Request $req)
    {
        $name = $req->input('name');
        $amount = $req->input('amount');
        
    DB::table('room_item')
    ->where('id',$req->id)
    ->update([
        'name'=>$name,
        'amount'=>$amount,
    ]);
    
    return Redirect::to('room_items')->withMessage('Item Updated Successfully');
    }
    
    public function roomitem_delete($id)
    {
        //echo"$id";
        DB::table('room_item')
        ->where('id', '=', $id)
        ->delete();
        
        return Redirect::to('room_items')->withMessage('Item Deleted successfully');
       
    }
    
    
    public function gb_cicoback(Request $req)
    {
        $id = $req->input('id');
        $days_count = $req->input('days_count');
        $total_room_pri = $req->input('total_room_pri');
        $total_ser_cha = $req->input('total_ser_cha');
        $dam_cla = $req->input('dam_cla');
        $total_amount = $req->input('total_amount');
        $final_remarks = $req->input('final_remarks');
        
        $status = "closed";
        
        /* DB::table('g_booking')
        ->where('id',$req->id)
        ->update([
            'days_count'=>$days_count,
            'total_room_price'=>$total_room_pri,
            'total_service_charge'=>$total_ser_cha,
            'damage_claim'=>$dam_cla,
            'total_amount'=>$total_amount,
            'remarks_final'=>$final_remarks,
            'status'=>$status,
            
        ]); */
        include 'conn.php';
        
        $query3="Select * from room_item where id='$dam_cla'";
        $stmt3= $conn->query($query3);
        while($row3 = $stmt3->fetch())
        {
            //$damage_name=$row3['name'];
            $damage_amount=$row3['amount'];
        }
        
        $net_amount = $damage_amount+$total_amount;
        $data1 = array(
            'id_booking'=>$id,
            'days_count'=>$days_count,
            'total_room_pri'=>$total_room_pri,
            'total_ser_cha'=>$total_ser_cha,
            'dam_cla'=>$dam_cla,
            'dam_cla_amount'=>$damage_amount,
            'total_amount'=>$net_amount,
            'final_remarks'=>$final_remarks,
            
            
        );
        DB::table('checkout_bill_temp')->insert($data1);
        
        
        
        //return view('receipt_view', compact('id'));
        return view('receipt_view_first', compact('id'));
    }
    
    
    
    public function finalsubmit($id)
    {
        include 'conn.php';
       //echo"$id"; 
        $status = "closed";
        
        $query3="Select * from checkout_bill_temp where id_booking ='$id'";
        $stmt3= $conn->query($query3);
        while($row3 = $stmt3->fetch())
        {
            $days_count=$row3['days_count'];
            $total_room_pri=$row3['total_room_pri'];
            $total_ser_cha=$row3['total_ser_cha'];
            $dam_cla=$row3['dam_cla'];
            $total_amount=$row3['total_amount'];
            $final_remarks=$row3['final_remarks'];
        }
        
         DB::table('g_booking')
         ->where('id',$id)
         ->update([
         'days_count'=>$days_count,
         'total_room_price'=>$total_room_pri,
         'total_service_charge'=>$total_ser_cha,
         'damage_claim'=>$dam_cla,
         'total_amount'=>$total_amount,
         'remarks_final'=>$final_remarks,
         'status'=>$status,
         ]);
         
         DB::table('g_booking_manager')
         ->where('id',$id)
         ->update([
            'status'=>$status,
         ]);
         
         $query31="Select * from g_booking where id ='$id'";
         $stmt31= $conn->query($query31);
         while($row31 = $stmt31->fetch())
         {
             $t_name=$row31['t_name'];
             $emp_id=$row31['emp_id'];
             $email_id=$row31['email_id'];
             $mobile_no=$row31['mobile_no'];
             $ci_date=$row31['ci_date'];
             $co_date=$row31['co_date'];
             $no_guest=$row31['no_guest'];
             $no_rooms=$row31['no_rooms'];
             $id=$row31['id'];
             $city=$row31['city'];
             $id_proof=$row31['id_proof'];
             $id_number=$row31['id_number'];
             $off_pri=$row31['off_pri'];
             $path=$row31['path'];
             $civil_id=$row31['civil_id'];
             $status=$row31['status'];
             $sel_obh=$row31['sel_obh'];
             $self_half_text=$row31['self_half_text'];
             $adults=$row31['adults'];
             $kids=$row31['kids'];
             $designation=$row31['designation'];
             $ci_time=$row31['ci_time'];
             $co_time=$row31['co_time'];
             $room_type=$row31['room_type'];
             $room_number=$row31['room_number'];
             
         }
         
         $explo1 = explode("-", $ci_date);
         $year1 =  $explo1[0];
         $month1 =  $explo1[1];
         $date1 =  $explo1[2];
         $ci_date1 = "$date1-$month1-$year1";
         
         $explo2 = explode("-", $co_date);
         $year2 =  $explo2[0];
         $month2 =  $explo2[1];
         $date2 =  $explo2[2];
         $co_date1 = "$date2-$month2-$year2";
         
         /* 
         $body2 = "Dear $t_name, <br>";
         $body2 .= "<br>";
         $body2 .= "Thank you, you have Checke-Out on $co_date1 $co_time.<br>";
         $body2 .= "Please find your Receipt details below.<br>";
         $body2 .= "<html><body><table border='1px' width='400px'>";
         $body2 .= "<tr> आयकर विभाग / INCOME TAX DEPARTMENT<br>अतिथि गृह / GUEST HOUSE<br><font size='2'> सं.2, आयकर कॉलोनी, इंफैन्ट्री रोड, बेंगलूरु – 560001<br>No.2, Income Tax Colony, Infantry Road, Bengaluru – 560001.<br>फोन/Ph. 080-22206978, 22206256, 22206240</font></tr>";
         $body2 .= "<tr><td>रसीद सं./Receipt No.:</td><td>$id</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>दिनांक/Date:</td><td>$co_date1</td></tr> ";
         $body2 .= "<tr><td>श्री/श्रीमती/Shri/Smt</td><td>$t_name</td><td>Civil Code/Employee ID</td><td>$emp_id</td><td>Mobile Number</td><td>$mobile_no</td></tr>";
         $body2 .= "<tr><td>Check-in Date</td><td>$ci_date1</td><td>Check-out Date</td><td>$co_date1</td><td>No of Rooms</td><td>$no_rooms</td></tr>";
         $body2 .= " <tr><td>Rooms Type</td><td>$room_type</td><td>Room Number</td><td>$room_number</td><td></td><td></td></tr>";
         $body2 .= " <tr><td>Total Room price</td><td colspan='5' style=\"text-align: right;\">$total_room_pri</td></tr>";
         $body2 .= "<tr><td>Total Service charge</td><td colspan='5' style=\"text-align: right;\">$total_ser_cha</td></tr>";
         $body2 .= " <tr><td>Damage Claim</td><td colspan='5' style=\"text-align: right;\">($item_name) $dam_cla</td></tr>";
         $body2 .= "<tr><td>रू./Rs.</td><td colspan='5' style=\"text-align: right;\">$total_amount</td></tr>";
         $body2 .= " <tr><td colspan='6' style=\"text-align: right;\">अतिथि गृह, बेंगलूरु/Guest House, Bengaluru.</td></tr>";
         $body2 .= "</table></body></html>";
         $body2 .= "<br>";
         $body2 .= "\r\nSincerely,\r\n";
         $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body2, function($message) use ($email_id, $body2)
         {
             $message->to($email_id)->subject('Guest House Booking Checke-IN');
             $message->setBody($body2, 'text/html');
         });
        

                        $contact = "91$mobile_no";
                        $content = "Dear $t_name,Thank you, you have Checke-Out on $co_date1 $co_time,Rs:$total_amount";
                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);

 
         //$admin_email = "gopalkrishna_b@lintechnokrats.com";
         $admin_email = "ito.hq.protocol@incometax.gov.in";
         
         $body1 = "Dear Admin, <br><br>";
         $body1 .= "Manager has Checke-Out for guest $t_name, Please find the details below<br><br>";
         $body1 .= "<html><body><table border='1px' width='400px'>";
         $body1 .= "<tr> आयकर विभाग / INCOME TAX DEPARTMENT<br>अतिथि गृह / GUEST HOUSE<br><font size='2'> सं.2, आयकर कॉलोनी, इंफैन्ट्री रोड, बेंगलूरु – 560001<br>No.2, Income Tax Colony, Infantry Road, Bengaluru – 560001.<br>फोन/Ph. 080-22206978, 22206256, 22206240</font></tr>";
         $body1 .= "<tr><td>रसीद सं./Receipt No.:</td><td>$id</td><td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td><td>दिनांक/Date:</td><td>$co_date1</td></tr> ";
         $body1 .= "<tr><td>श्री/श्रीमती/Shri/Smt</td><td>$t_name</td><td>Civil Code/Employee ID</td><td>$emp_id</td><td>Mobile Number</td><td>$mobile_no</td></tr>";
         $body1 .= "<tr><td>Check-in Date</td><td>$ci_date1</td><td>Check-out Date</td><td>$co_date1</td><td>No of Rooms</td><td>$no_rooms</td></tr>";
         $body1 .= " <tr><td>Rooms Type</td><td>$room_type</td><td>Room Number</td><td>$room_number</td><td></td><td></td></tr>";
         $body1 .= " <tr><td>Total Room price</td><td colspan='5' style=\"text-align: right;\">$total_room_pri</td></tr>";
         $body1 .= "<tr><td>Total Service charge</td><td colspan='5' style=\"text-align: right;\">$total_ser_cha</td></tr>";
         $body1 .= " <tr><td>Damage Claim</td><td colspan='5' style=\"text-align: right;\">($item_name) $dam_cla</td></tr>";
         $body1 .= "<tr><td>रू./Rs.</td><td colspan='5' style=\"text-align: right;\">$total_amount</td></tr>";
         $body1 .= " <tr><td colspan='6' style=\"text-align: right;\">अतिथि गृह, बेंगलूरु/Guest House, Bengaluru.</td></tr>";
         $body1 .= "</table></body></html>";
         $body1 .= "<br>";
         $body1 .= "\r\nSincerely,<br>";
         $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body1, function($message) use ($admin_email, $body1)
         {
             $message->to($admin_email)->subject('Guest House Booking Checke-Out');
             $message->setBody($body1, 'text/html');
         });


			$contact = "918892022172";
                        $content = "Dear Admin, $t_name Checke-Out on $co_date1 $co_time,Room Number:$room_number,Rs:$total_amount";
			$curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, "http://portal.thundersms.com/api/v2/sms/send?access_token=dd364a7e98524378e5aecf2a4f6584d5&message=$content&sender=ITDBLR&to=$contact&service=T");
                        curl_setopt($curl, CURLOPT_POST, 1);
                        //$str = http_build_query($arr);
                        curl_setopt($curl, CURLOPT_POSTFIELDS, 1);//Setting post data as xml
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        $result = curl_exec($curl);
                        echo curl_error($curl);
                        $result =json_decode($result);
                        print_r($result);
                        curl_close($curl);


	 */					
         
       return view('receipt_view', compact('id'));
    }
    
    
    
    
    
    public function manager_report_down(Request $req)
    {
        //echo"hello";
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        $type_accomm = $req->input('type_accomm');
        $room_type = $req->input('room_type');
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        $results = DB::table('g_booking_manager')->where(function($query) use ($ci_date1, $co_date1, $type_accomm, $room_type) {
            if ( ! empty($ci_date1)) {
                $query->whereBetween('ci_date', [$ci_date1, $co_date1]);
            }
            if ( ! empty($type_accomm)) {
                $query->where('type_accomm', '=', $type_accomm);
            }
            if ( ! empty($room_type)) {
                $query->where('room_type', '=', $room_type);
            }
        })->get();
        
        return view('manager_reports_view', compact(['results']));
        
    }
    
    public function gbcancel($id)
    {
        //echo"$id";
        DB::table('g_booking')
        ->where('id', '=', $id)
        ->delete();
        
        return Redirect::to('home')->withMessage('Booking cancelled successfully');
        
    }
    
    
    public function co_rec_gencancel($id)
    {
        //echo"$id";
         DB::table('checkout_bill_temp')
        ->where('id_booking', '=', $id)
        ->delete();
        
        return view('corec_gen_view', compact('id')); 
    }
    
    public function gb_updategb($id)
    {
        //echo"$id";
        return view('room_update_view_admin', compact('id'));
    }
    
    
    
    
    
    public function gb_app_rej_admreturn(Request $req)
    {
        $ci_date = $req->input('ci_date');
        $co_date = $req->input('co_date');
        $remarks = $req->input('remarks');
        $fromtime = $req->input('fromtime');
        $totime = $req->input('totime');
        $remarks_old = $req->input('remarks_old');
        
        
        $explo1 = explode("-", $ci_date);
        $date1 =  $explo1[0];
        $month1 =  $explo1[1];
        $year1 =  $explo1[2];
        $ci_date1 = "$year1-$month1-$date1";
        
        $explo2 = explode("-", $co_date);
        $date2 =  $explo2[0];
        $month2 =  $explo2[1];
        $year2 =  $explo2[2];
        $co_date1 = "$year2-$month2-$date2";
        
        $u_images=array();
        if($files=$req->file('upload_file')){
            foreach($files as $file){
                $name1=$file->getClientOriginalName();
                $destinationPath = public_path('/attachment');
                $file->move($destinationPath,$name1);
                $u_images[]=$name1;
            }
        }
        else
        {
            //$name1='';
            $u_images[]='';
        }
        
        $id = $req->input('id');
        $path_names = $req->input('path_names');
        
        $new_fil = implode("|",$u_images);
        $upath_merge = "$path_names|$new_fil";
        $admin_email = Auth::user()->email;
        date_default_timezone_set("Asia/Kolkata");
        $date_tim = date("Y-m-d h:i:s");
        
        $remarks_new = "$remarks_old|$remarks";
        
        DB::table('g_booking')
        ->where('id',$req->id)
        ->update([
        
            'ci_date'=>$ci_date1,
            'co_date'=>$co_date1,
            'path'=>$upath_merge,
            'remarks'=>$remarks_new,
            'admin_update_date_time'=>$date_tim,
            'admin_id'=>$admin_email,
            'ci_time'=>$fromtime,
            'co_time'=>$totime,
        ]);
        
        
        
        
        /*   $body2 = "Dear $t_name, <br>";
         $body2 .= "<br>";
         $body2 .= "Admin has $ap_rej your guest house booking request.<br>";
         $body2 .= "Please find your booking details below.<br>";
         $body2 .= "<html><body><table border='1px' width='400px'>";
         $body2 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
         $body2 .= "<tr><td><b>Check-in Date</b></td><td>$ci_date</td></tr>";
         $body2 .= "<tr><td><b>Check-out Date</b></td><td>$co_date</td></tr>";
         $body2 .= "<tr><td><b>No of Guest's</b></td><td>$no_guest</td></tr>";
         $body2 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
         $body2 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
         $body2 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
         $body2 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
         $body2 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
         $body2 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
         $body2 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
         $body2 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
         $body2 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
         $body2 .= "<tr><td><b>Admin Remarks</b></td><td>$remarks</td></tr>";
         $body2 .= "<tr><td><b>Note:</b></td><td>Please carry a valid govt. issued address ID proof.</td></tr>";
         $body2 .= "</table></body></html>";
         
         
         $body2 .= "<br>";
         $body2 .= "\r\nSincerely,\r\n";
         $body2 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body2, function($message) use ($email_id, $body2)
         {
         $message->to($email_id)->subject('Guest House Booking');
         $message->setBody($body2, 'text/html');
         });
         
         
         
         $body1 = "Dear Admin, <br><br>";
         $body1 .= "You have $ap_rej guest house booking request, Please find the details below<br><br>";
         $body1 .= "<html><body><table border='1px' width='400px'>";
         $body1 .= "<tr><td><b>City</b></td><td>$city</td></tr>";
         $body1 .= "<tr><td><b>Check-in Date</b></td><td>$ci_date</td></tr>";
         $body1 .= "<tr><td><b>Check-out Date</b></td><td>$co_date</td></tr>";
         $body1 .= "<tr><td><b>No of Guest's</b></td><td>$no_guest</td></tr>";
         $body1 .= "<tr><td><b>No of Rooms</b></td><td>$no_rooms</td></tr>";
         $body1 .= "<tr><td><b>Traveller Name</b></td><td>$t_name</td></tr>";
         $body1 .= "<tr><td><b>Employee ID</b></td><td>$emp_id</td></tr>";
         $body1 .= "<tr><td><b>Civil ID</b></td><td>$civil_id</td></tr>";
         $body1 .= "<tr><td><b>Email-ID</b></td><td>$email_id</td></tr>";
         $body1 .= "<tr><td><b>Mobile Number</b></td>$mobile_no<td></td></tr>";
         $body1 .= "<tr><td><b>ID Proof</b></td><td>$id_proof</td></tr>";
         $body1 .= "<tr><td><b>ID Numer</b></td><td>$id_number</td></tr>";
         $body1 .= "<tr><td><b>Offical/Private</b></td>$off_pri<td></td></tr>";
         $body1 .= "<tr><td><b>Remarks</b></td><td>$remarks</td></tr>";
         $body1 .= "</table></body></html>";
         $body1 .= "<br>";
         $body1 .= "\r\nSincerely,<br>";
         $body1 .= "*Please note: This is a system generated email and was sent from an address that cannot accept incoming e-mail.\r\n";
         Mail::raw($body1, function($message) use ($admin_email, $body1)
         {
         $message->to($admin_email)->subject('Guest House Booking');
         $message->setBody($body1, 'text/html');
         }); */
        
          
            return Redirect::to('home')->withMessage('Guest House Booking Updated successfully');
        
        
    }
    
    
    
    
    
    
    
    
}
