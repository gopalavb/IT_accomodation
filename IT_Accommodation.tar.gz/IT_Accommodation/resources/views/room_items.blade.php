<?php
//echo"$id view";
?>

@include('layouts.app')

             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 



      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Add Room Item</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif 

 <form class="form-horizontal" method="POST" action="{{ secure_asset('add_item') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}


<div class="col-sm-12">
                    
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Name</label>
                                <input type="text" name='name' class="form-control" required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Amount</label>
                                <input type="text" name='amount' class="form-control" required>
                            </div>  
                        </div>
                        
                        
                        
                        
                                            
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' name='Submit' class="btn btn-primary"  value='Submit' >
                      
                    <br><br> 
                    <div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Name</th>
        <th>Amount</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
    <?php

    include 'conn.php';

            $query="Select * from room_item";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $name=$row['name'];
               $amount=$row['amount'];
               
               $id=$row['id'];
      echo"<tr><td>$name</td><td>$amount</td>";
      echo"<td><a href='room_item_update/$id'><i class='fa fa-edit'></i></td>"; ?>
      <td><a href='room_item_delete/<?php echo"$id"; ?>' onClick="return confirm('Are you sure do you want to Delete ?');"><i class='fa fa-trash'></i></td></tr>
        <?php 
           }
      ?>
      
    </tbody>
  </table>
  </div>
</div>             
                    </div>
</form>


    </div>



  @include('layouts/footer_public')
