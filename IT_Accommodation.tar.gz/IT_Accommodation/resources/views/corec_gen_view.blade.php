<?php
//echo"$id";
?>
<?php
//echo"manager: $id";
?>


@include('layouts.app')

             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 




    <?php
include 'conn.php';

            $query="Select * from g_booking_manager where id_booking='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               //$id=$row['id'];
           	   $civil_id=$row['civil_id'];
           	   $status=$row['status'];
           	   $room_type=$row['room_type'];
           	   $room_no=$row['room_no'];
           	   $off_pri=$row['off_pri'];
           	   $type_accomm=$row['type_accomm'];
           	   
           	   $ci_time=$row['ci_time'];
           	   $co_time=$row['co_time'];
      
           }
           
           $explo1 = explode("-", $ci_date);
           $year1 =  $explo1[0];
           $month1 =  $explo1[1];
           $date1 =  $explo1[2];
           $ci_date1 = "$date1-$month1-$year1";
           
           $explo2 = explode("-", $co_date);
           $year2 =  $explo2[0];
           $month2 =  $explo2[1];
           $date2 =  $explo2[2];
           $co_date1 = "$date2-$month2-$year2";
      ?>
      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Check-Out and Receipt Generation</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif 

 <form class="form-horizontal" method="POST" action="{{ URL::asset('gb_cico_back') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}

<input type="hidden" name="id" value="<?php echo"$id"; ?>">
<div class="col-sm-12">
                    
                      
                        
                        
                       <div class="row">
                            <div class="col-sm-6 form-group">
                                <label>Traveller Name</label>
                                <input type="text" name='name' class="form-control" value="<?php echo"$t_name"; ?>" readonly>
                            </div>      
                             <div class="col-sm-6 form-group">
                                <label>Employee ID</label>
                                <input type="text" name='emp_id' class="form-control" value="<?php echo"$emp_id"; ?>" readonly>
                            </div> 
                        </div>
                        
                        	
                        
                       
                        <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Email-ID</label>
                                <input type="email" name='email_id' class="form-control" required value="<?php echo"$email_id"; ?>" readonly>
                            </div>
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" pattern="[0-9]{10}" value="<?php echo"$mobile_no"; ?>" required readonly>
                            </div>   
                        </div>
                        
                        

                        
                        <div class="row">
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" value="<?php echo"$ci_date1"; ?>" required readonly>
                            </div>      
                            <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="fromtime" class="form-control" style="width: 100px;" required>
                                <option value="<?php echo"$ci_time"; ?>"><?php echo"$ci_time"; ?></option>
                            <option>00:00</option>
                           <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>
							</select>
                        	</div> 
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2"  value="<?php echo"$co_date1"; ?>" required readonly>
                            </div>  
                             <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="totime" class="form-control" style="width: 100px;" required>
                                <option value="<?php echo"$co_time"; ?>"><?php echo"$co_time"; ?></option>
                            <option>00:00</option>
                            <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>

                        </select>
                            </div>
                        </div>
                        		
                        		<?php 
                        		function dateDiffInDays($date1, $date2)
                        		{
                        		    // Calulating the difference in timestamps
                        		    $diff = strtotime($date2) - strtotime($date1);
                        		    
                        		    // 1 day = 24 hours
                        		    // 24 * 60 * 60 = 86400 seconds
                        		    return abs(round($diff / 86400));
                        		}
                        		
                        		// Start date
                        		$date1 = $ci_date1;
                        		
                        		// End date
                        		$date2 = $co_date1;
                        		
                        		// Function call to find date difference
                        		$dateDiff = dateDiffInDays($date1, $date2);
                        		
                        		// Display the result
                        		//printf("Difference between two dates: ". $dateDiff . " Days "); 
                
                        		?>
                        		
                        		
                        		 <div class="row">
                            <div class="col-sm-2 form-group">
                                <label>No of Days</label>
                                <input type="text" name="days_count" id="days" value="<?php echo"$dateDiff"; ?>" class="form-control" readonly>
                            </div>      
                            
                            <?php 
                            //$room_type
                            $exp_room = explode("|", $room_type);
                            $expr_count = count($exp_room); 
                            $expr0 = $exp_room[0];
                            $expr1 = $exp_room[1];
                            //$off_pri
                            
                            if($expr_count == "1")
                            {
                                    $query10="Select * from amount_service where id='$expr0'";
                                    $stmt10= $conn->query($query10);
                                    while($row10 = $stmt10->fetch())
                                    {
                                        $official_tour=$row10['official_tour'];
                                        $private=$row10['private'];
                                        $official_other_dept=$row10['official_other_dept'];
                                        $family_menbers=$row10['family_menbers'];
                                        $sc_off_to_pri=$row10['sc_off_to_pri'];
                                        $sc_official_other_dept=$row10['sc_official_other_dept'];
                                        $sc_family_menbers=$row10['sc_family_menbers'];
                                    }
                                    
                                    if($type_accomm == "Offical")
                                    {
                                        $price_per_day = $official_tour;
                                        $service_charges = $sc_off_to_pri;
                                    }
                                    else if($type_accomm == "Private")
                                    {
                                        $price_per_day = $private;
                                        $service_charges = $sc_off_to_pri;
                                    }
                                    else if($type_accomm == "Other department")
                                    {
                                        $price_per_day = $official_other_dept;
                                        $service_charges = $sc_official_other_dept;
                                    }
                                    else if($type_accomm == "Family")
                                    {
                                        $price_per_day = $family_menbers;
                                        $service_charges = $sc_family_menbers;
                                    }
                                    
                                    $total_room_price = $price_per_day*$dateDiff;
                                    $service_charge_totle = $service_charges*$dateDiff;
                                    $total_with_days = (($price_per_day*$dateDiff)+$service_charge_totle);
                            }
                            
                            else if($expr_count == "2")
                            {
                                    $query10="Select * from amount_service where id='$expr0'";
                                    $stmt10= $conn->query($query10);
                                    while($row10 = $stmt10->fetch())
                                    {
                                        $official_tour=$row10['official_tour'];
                                        $private=$row10['private'];
                                        $official_other_dept=$row10['official_other_dept'];
                                        $family_menbers=$row10['family_menbers'];
                                        $sc_off_to_pri=$row10['sc_off_to_pri'];
                                        $sc_official_other_dept=$row10['sc_official_other_dept'];
                                        $sc_family_menbers=$row10['sc_family_menbers'];
                                    }
                                    $query11="Select * from amount_service where id='$expr1'";
                                    $stmt11= $conn->query($query11);
                                    while($row11 = $stmt11->fetch())
                                    {
                                        $official_tour_2=$row11['official_tour'];
                                        $private_2=$row11['private'];
                                        $official_other_dept_2=$row11['official_other_dept'];
                                        $family_menbers_2=$row11['family_menbers'];
                                        $sc_off_to_pri_2=$row11['sc_off_to_pri'];
                                        $sc_official_other_dept_2=$row11['sc_official_other_dept'];
                                        $sc_family_menbers_2=$row11['sc_family_menbers'];
                                    }
                                    
                                    
                                    if($type_accomm == "Offical")
                                    {
                                        $price_per_day = $official_tour+$official_tour_2;
                                        $service_charges = $sc_off_to_pri+$sc_off_to_pri_2;
                                    }
                                    else if($type_accomm == "Private")
                                    {
                                        $price_per_day = $private+$private_2;
                                        $service_charges = $sc_off_to_pri+$sc_off_to_pri_2;
                                    }
                                    else if($type_accomm == "Other department")
                                    {
                                        $price_per_day = $official_other_dept+$official_other_dept_2;
                                        $service_charges = $sc_official_other_dept+$sc_official_other_dept_2;
                                    }
                                    else if($type_accomm == "Family")
                                    {
                                        $price_per_day = $family_menbers+$family_menbers_2;
                                        $service_charges = $sc_family_menbers+$sc_family_menbers_2;
                                    }
                                    
                                    $total_room_price = $price_per_day*$dateDiff;
                                    $service_charge_totle = $service_charges*$dateDiff;
                                    $total_with_days = (($price_per_day*$dateDiff)+$service_charge_totle);
                                    
                            }
                            ?>
                            
                            <div class="col-sm-2 form-group">
                                <label>No of Rooms</label>
                                <input type="text" name="no_rooms" value="<?php echo"$expr_count"; ?>" class="form-control">
                            </div>
                            
                            <div class="col-sm-2 form-group">
                                <label>Room Number</label>
                                <input type="text" name="no_rooms" value="<?php echo"$room_no"; ?>" class="form-control">
                            </div> 
                            
                            <div class="col-sm-2 form-group">
                                <!-- <label>Per day price</label> -->
                                <label>Total Room price</label>
                                <input type="text" name="total_room_pri" id="pdp" value="<?php echo"$total_room_price"; ?>" class="form-control">
                            </div> 
                            <div class="col-sm-2 form-group">
                                <label>Total Service charge</label>
                                <input type="text" name="total_ser_cha" id="sc" value="<?php echo"$service_charge_totle"; ?>" class="form-control">
                            </div>   
                            <div class="col-sm-2 form-group">
                                <label>Damage Claim</label>
                                <select name="dam_cla" class="form-control"> 
                                <option value="">--select--</option>
                                <?php 
                                $query20="Select * from room_item";
                                $stmt20= $conn->query($query20);
                                while($row20 = $stmt20->fetch())
                                {
                                    $id=$row20['id'];
                                    $name=$row20['name'];
                                    $amount=$row20['amount'];
                                    echo"<option value='$id'>$name</option>";
                                }
                                    
                                ?>
                                </select>
                            </div>  
                            <div class="col-sm-2 form-group">
                                <label>Total Amount</label>
                                <input type="text" name="total_amount" id="total" value="<?php echo"$total_with_days"; ?>" class="form-control">
                            </div>  
                        </div>
                        		
                        
                        
                        
                        
                        
                         
                        
                        
                              
                             
                        
                        <div class="row">
                           
                            <div class="col-sm-6 form-group">
                                <label>Remarks</label>
                                <textarea rows="" cols="" name="final_remarks" class="form-control"></textarea>
                            </div>      
                        </div> 
                        
                                   
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' class="btn btn-primary"  value='Submit' >
                      
                    <br><br>              
                    </div>
</form>


    </div>



  @include('layouts/footer_public')
  
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "{{ URL::asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "{{ URL::asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>


<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">


$("#sc").keyup(function(){
	  $("#total").html('');

	  var n1 = $("#days").val() || 0;
	  var n2 = $("#pdp").val() || 0;
	  var n3 = $("#sc").val() || 0;

	  var ans = ((parseInt(n1) * parseInt(n2)) + parseInt(n3));
	 
	  
	  document.getElementById("total").value = ans;
});
	</script>
