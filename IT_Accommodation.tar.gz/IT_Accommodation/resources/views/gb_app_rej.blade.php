<?php
//echo"$id view";
?>

@include('layouts.app')

             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 
  <script type="text/javascript" src="{{ secure_asset('./js/jquery.min.js') }}"></script>   
   <script type="text/javascript">
$(document).ready(function() {
	$('#wait_1').hide();
	$('#drop_1').change(function(){
	  $('#wait_1').show();
	  $('#result_1').hide();
      $.get("{{ secure_asset('func9.php') }}", {
		func: "drop_1",
		drop_var: $('#drop_1').val()
      }, function(response){
        $('#result_1').fadeOut();
        setTimeout("finishAjax('result_1', '"+escape(response)+"')", 400);
      });
    	return false;
	});
});

function finishAjax(id, response) {
  $('#wait_2').hide();
  $('#'+id).html(unescape(response));
  $('#'+id).fadeIn();
}

$(document).ready(function() {
	$('#wait_2').hide();
	$('#drop_2').change(function(){
	  $('#wait_2').show();
	  $('#result_2').hide();
      $.get("{{ secure_asset('func10.php') }}", {
		func: "drop_2",
		drop_var: $('#drop_2').val()
      }, function(response){
        $('#result_2').fadeOut();
        setTimeout("finishAjax('result_2', '"+escape(response)+"')", 400);
      });
    	return false;
	});
});
</script> 




    <?php
include 'conn.php';

            $query="Select * from g_booking where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
           	   $city=$row['city'];
           	   $id_proof=$row['id_proof'];
           	   $id_number=$row['id_number'];
           	   $off_pri=$row['off_pri'];
           	   $path=$row['path'];
           	   $civil_id=$row['civil_id'];
           	   $status=$row['status'];
           	   $sel_obh=$row['sel_obh'];
           	   $self_half_text=$row['self_half_text'];
           	   $adults=$row['adults'];
           	   $kids=$row['kids'];
           	   $designation=$row['designation'];
           	   $ci_time=$row['ci_time'];
           	   $co_time=$row['co_time'];
      
           }
           
           $explo1 = explode("-", $ci_date);
           $year1 =  $explo1[0];
           $month1 =  $explo1[1];
           $date1 =  $explo1[2];
           $ci_date1 = "$date1-$month1-$year1";
           
           $explo2 = explode("-", $co_date);
           $year2 =  $explo2[0];
           $month2 =  $explo2[1];
           $date2 =  $explo2[2];
           $co_date1 = "$date2-$month2-$year2";
      ?>
      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Guest House Booking</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif 

 <form class="form-horizontal" method="POST" action="{{ secure_asset('gb_app_rej_adm') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}

<input type="hidden" name="id" value="<?php echo"$id"; ?>">
<input type="hidden" name="path_names" value="<?php echo"$path"; ?>">
<div class="col-sm-12">
                    
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>City</label>
                                 <select name="city" class="form-control" readonly required>
                                         <option value="<?php echo"$city"; ?>"><?php echo"$city"; ?></option>
                                         <option value="Bengaluru">Bengaluru</option>
                                         <!-- <option value="Goa">Goa</option> -->
                                 </select>
                            </div>  
                            
                               
                        </div>
                        <div class="row">
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" value="<?php echo"$ci_date1"; ?>" readonly required>
                            </div>      
                            <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="fromtime" class="form-control" style="width: 100px;" required>
                                <option value="<?php echo"$ci_time"; ?>"><?php echo"$ci_time"; ?></option>
                            <option>00:00</option>
                           <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>
							</select>
                        	</div>
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2" value="<?php echo"$co_date1"; ?>" readonly required>
                            </div>
                            
                             <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="totime" class="form-control" style="width: 100px;" required>
                                <option value="<?php echo"$co_time"; ?>"><?php echo"$co_time"; ?></option>
                            <option>00:00</option>
                            <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>

                        </select>
                            </div>
                              
                        </div>  
                        
                        
                        <div class="row">
                            <!-- <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>No of Guest's</label>
                                <select name="no_guest" class="form-control" readonly required>
                                         <option value="<?php echo"$no_guest"; ?>"><?php echo"$no_guest"; ?></option>
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option>
                                 </select>
                            </div>
                             -->      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>No of Rooms</label>
                                <select name="no_rooms" class="form-control" readonly required>
                                         <option value="<?php echo"$no_rooms"; ?>"><?php echo"$no_rooms"; ?></option>
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                 </select>
                            </div>  
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Traveller Name</label>
                                <input type="text" name='t_name' class="form-control" value="<?php echo"$t_name"; ?>" readonly required>
                            </div>
                        </div> 
                        
                     
                        <div class="row">
                       
    <div class='col-sm-6 form-group'>
    <label><font color='red'>*</font>No of Adults</label>
    <select name='no_adults' class='form-control' readonly required>
    <option value='<?php echo"$adults"; ?>'><?php echo"$adults"; ?></option>
    <option value='$adult'></option>
    </select>
    </div>
    
    
    <div class='col-sm-6 form-group'>
    <label>No of Kids</label>
    <select name='no_kids' class='form-control' readonly>
    <option value='<?php echo"$kids"; ?>'><?php echo"$kids"; ?></option>
    </select>
    </div>
                        </div>
                     
                     
                    
                    
                    <?php 
                        if($no_rooms == "1")
                        {
                        ?>
                        <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Rooms Type</label>
                                <select name="room_type[]" id="drop_1" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <?php 
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>
                            <div class="col-sm-6 form-group">
                            <span id="result_1" style="display: none; width: 1000px;"></span>
                            </div>
                            <!-- <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Room Number</label>
                                 <input type="text" name='room_number[]' class="form-control" required> 
                            </div>  --> 
                        </div>
                        <?php 
                        }
                        else if($no_rooms == "2")
                        {
                        ?>
                         
                         <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font> Rooms Type</label>
                                <select name="room_type[]" id="drop_1" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <?php 
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>
                            
                             <div class="col-sm-6 form-group">
                            <span id="result_1" style="display: none; width: 1000px;"></span>
                            </div> 
                        </div>
                        
                        <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Rooms Type</label>
                                <select name="room_type[]" id="drop_2" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <?php 
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>
                            
                           <div class="col-sm-6 form-group">
                            <span id="result_2" style="display: none; width: 1000px;"></span>
                            </div> 
                        </div>
                        <?php 
                        }
                        else
                        {
                         ?>
                         <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Rooms Type</label>
                                <select name="room_type[]" id="drop_1" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <?php 
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>
                            
                           <!--  <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Room Number</label>
                                 <input type="text" name='room_number[]' class="form-control" required> 
                            </div> -->  
                        </div>
                         <?php 
                        }
                         ?> 
                     
                     
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Designation</label>
                                <input type="text" name='designation' class="form-control" value="<?php echo"$designation"; ?>" readonly required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Civil Code/Employee ID</label>
                                <input type="text" name='emp_id' class="form-control" value="<?php echo"$emp_id"; ?>" readonly required>
                            </div>  
                        </div>
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Email-ID</label>
                                <input type="email" name='email_id' value="<?php echo"$email_id"; ?>" class="form-control" readonly>
                            </div>
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" value="<?php echo"$mobile_no"; ?>" pattern="[0-9]{10}" readonly required>
                            </div>  
                        </div>
                                                
                    					
                    					<div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>ID Proof</label>
                                 <select name="id_proof" class="form-control" required readonly>
                                         <option value="<?php echo"$id_proof"; ?>"><?php echo"$id_proof"; ?></option>
                                         <option value="Department ID">Department ID</option>
                                         <option value="Aadhaar card">Aadhaar Card</option>
                                         <option value="Permanent Account Number">Permanent Account Number</option>
                                         <option value="Driving License">Driving License</option>
                                         <!-- <option value="Others">Other's</option> -->
                                         <!-- <option value=""></option>
                                         <option value=""></option>
                                          -->
                                 </select>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>ID Number</label>
                                <input type="text"  name="id_number" value="<?php echo"$id_number"; ?>" class="form-control" readonly>
                            </div>  
                        </div>
                        
                        <div class="row">
                              
                              <div class="col-sm-6 form-group">
                                <label></label>
                                 <select name="sel_obh" id="se_ob" class="form-control" readonly>
                                         <option value="<?php echo"$sel_obh"; ?>"><?php echo"$sel_obh"; ?></option>
                                         <option value="self">self</option>
                                         <option value="on behalf of">on behalf of</option>
                                 </select>
                            </div>
                              
                              
                            <div class="col-sm-6 form-group">
                                <br>
                                <?php 
                                if($sel_obh == "self")
                                {
                                ?>
                                        <?php 
                                        if($off_pri == "Offical")
                                        {
                                        ?>
                                        <input type="radio" name='off_pri' value='Offical' checked  >&nbsp;&nbsp; Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private'  > &nbsp;&nbsp; Private
                                        <?php 
                                        }
                                        else if($off_pri == "Private")
                                        {
                                            ?>
                                         <input type="radio" name='off_pri' value='Offical'  >&nbsp;&nbsp;Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private' checked  >&nbsp;&nbsp;Private   
                                            
                                            <?php 
                                        }
                                        else 
                                        {
                                        ?>
                                        <input type="radio" name='off_pri' value='Offical' >&nbsp;&nbsp;Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private'>&nbsp;&nbsp;Private
                                        <?php 
                                        }
                                }
                                else 
                                {
                                ?>
                                      <input type="text"  name="self_half_text" value="<?php echo"$self_half_text"; ?>" class="form-control" readonly>
                                <?php 
                                }
                                ?>
                            </div>  
                            
                            
                                
                        </div>
                    		
                    		
                    		 <div class="row">
                            <div class="col-sm-6 form-group">
                            
                            <?php 
                            $exp1 = explode("|",$path);
                            $exp_count = count($exp1);
                            for($i=0;$i<$exp_count;$i++)
                            {
                            ?>
                            
                            <a href="{!! secure_asset("attachment/$exp1[$i]") !!}" target="_blank">Guest Uploaded documents</a><br>
                            <?php 
                            }
                            ?>
                            <br>
                                <label><font color='red'>*</font>Browse & Upload</label>
                                
                                <input type="file" name="upload_file[]" multiple>
                            </div>      
                              
                        </div>	
                        
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label>Admin Remarks</label>
                                
                                <textarea rows="" cols="" name="remarks" class="form-control"></textarea>
                            </div>      
                              
                        </div>		
                                            
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' name='Approve' class="btn btn-primary"  value='Approve' >
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type='submit' name='Reject' class="btn btn-primary"  value='Reject' >   
                    <br><br>              
                    </div>
</form>


    </div>



  @include('layouts/footer_public')
  
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "{{ secure_asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "{{ secure_asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
