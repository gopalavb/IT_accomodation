<?php
//echo"$id view";
?>

@include('layouts.app')

             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 




 
      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Guest House Booking Report</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif 

 <form class="form-horizontal" method="POST" action="{{ secure_asset('manager_report') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}


<div class="col-sm-12">
                    
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>From Date</label>
                                <input type="text" name="ci_date" id="datepicker1" required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>To Date</label>
                                <input type="text" name="co_date" id="datepicker2" required>
                            </div>  
                        </div>  
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label>Type of Accommodation</label>
                                <select name="type_accomm" class="form-control">
                                         <option value="">--Select--</option>
                                         <option value="Offical">Offical Tour</option>
                                         <option value="Private">Private</option>
                                         <option value="Other department">Offical/Officers of Other Department</option>
                                         <option value="Family">Family Members of Department Officers</option>
                                 </select>
                            </div>      
                            <div class="col-sm-6 form-group">
                               <label>Rooms Type</label>
                                <select name="room_type" id="drop_1" class="form-control">
                                         <option value="">--Select--</option>
                                         <?php 
                                         include 'conn.php';
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>  
                        </div> 
                        
                       
                        
                                                
                    		
                                            
                   
                  
                    <input type='submit' name='Reject' class="btn btn-primary"  value='Generate Report' >   
                    <br><br>              
                    </div>
</form>


    </div>



  @include('layouts/footer_public')
  
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            showOn: "button",
            buttonImage: "{{ secure_asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
           showOn: "button",
            buttonImage: "{{ secure_asset('images_3/calendar.gif') }}",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
