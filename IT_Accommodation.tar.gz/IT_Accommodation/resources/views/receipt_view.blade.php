<?php
//echo"$id";
?>
<?php
//echo"$id";
?>
<?php
//echo"manager: $id";
?>
@include('layouts.app')



<!--    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">


<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script> --> 
<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>

    <?php
include 'conn.php';

            $query="Select * from g_booking where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $id=$row['id'];
           	   $civil_id=$row['civil_id'];
           	   $no_rooms=$row['no_rooms'];
           	   
           	   $total_room_price =$row['total_room_price'];
           	   $total_service_charge=$row['total_service_charge'];
           	   $total_amount=$row['total_amount'];
           	   $damage_claim=$row['damage_claim'];
           	   
      
           }
           
           $explo1 = explode("-", $ci_date);
           $year1 =  $explo1[0];
           $month1 =  $explo1[1];
           $date1 =  $explo1[2];
           $ci_date1 = "$date1-$month1-$year1";
           
           $explo2 = explode("-", $co_date);
           $year2 =  $explo2[0];
           $month2 =  $explo2[1];
           $date2 =  $explo2[2];
           $co_date1 = "$date2-$month2-$year2";
           
           
           $query2="Select * from g_booking_manager where id='$id'";
           $stmt2= $conn->query($query2);
           while($row2 = $stmt2->fetch())
           {
               $room_type=$row2['room_type'];
               $room_no=$row2['room_no'];
           }
           
           $query3="Select * from room_item where id='$damage_claim'";
           $stmt3= $conn->query($query3);
           while($row3 = $stmt3->fetch())
           {
               $damage_name=$row3['name'];
               $damage_amount=$row3['amount'];
           }
           
      ?>
      
    

<div class="container minheight">

<section id="main-content">
      <section class="wrapper">
        <!-- <h3><i class="fa fa-angle-right"></i> Form Components</h3> -->
        <!-- BASIC FORM ELELEMNTS -->
         @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              
               

<center>
<div class="table-responsive">

<div id="printableArea">


<table class="table table-striped" style="width: 1000px;">
                <thead>
  <tr><th colspan="6" style="text-align: center;">
  आयकर विभाग / INCOME TAX DEPARTMENT
 <br>
  अतिथि गृह / GUEST HOUSE
 <br>
  <font size="2"> सं.2, आयकर कॉलोनी, इंफैन्ट्री रोड, बेंगलूरु – 560001
 <br>
 No.2, Income Tax Colony, Infantry Road, Bengaluru – 560001.
 <br>
 फोन/Ph. 080-22206978, 22206256, 22206240
 </font>
 </th></tr>            
 </thead>
                <tbody>
                <tr>
 <td>रसीद सं./Receipt No.:</td><td></td>
 <td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td>
 <td>दिनांक/Date:</td><td><?php echo"$co_date1"; ?></td>
 
 </tr> 
 <tr>
 <td>श्री/श्रीमती/Shri/Smt</td><td><?php echo"$t_name"; ?></td>
 <td>Civil Code/Employee ID</td><td><?php echo"$emp_id"; ?></td>
 <td>Mobile Number</td><td><?php echo"$mobile_no"; ?></td>
 
 </tr>        
      
<tr>
<td>Check-in Date</td><td><?php echo"$ci_date1"; ?></td>
 <td>Check-out Date</td><td><?php echo"$co_date1"; ?></td>
 <td>No of Rooms</td><td><?php echo"$no_rooms"; ?></td>

 </tr>
 <?php 
 $exp_roo = explode("|", $room_type);
 $exp_r1 = $exp_roo[0];
 $exp_r2 = $exp_roo[1];


$exp_rono = explode("|", $room_no);
$exp_rn1 = $exp_rono[0];
$exp_rn2 = $exp_rono[1];




?>
 <tr>
  <td>Rooms Type</td><td><?php 
  //echo"$exp_r1   $exp_r2";
  $query4="Select * from amount_service where id='$exp_r1'";
  $stmt4= $conn->query($query4);
  while($row4 = $stmt4->fetch())
  {
      $type_of_accd1 =$row4['type_of_accd'];
  }
  $query5="Select * from amount_service where id='$exp_r2'";
  $stmt5= $conn->query($query5);
  while($row5 = $stmt5->fetch())
  {
      $type_of_accd2 =$row5['type_of_accd'];
  }
  
  echo"$type_of_accd1 <br>  $type_of_accd2";
  
  ?></td>
 <td>Room Number</td><td><?php echo"$exp_rn1 <br> $exp_rn2"; ?></td>
 <td></td><td></td>
 </tr>
 
 <tr>
 <td>&nbsp;</td><td>&nbsp;</td>
 <td>&nbsp;</td><td>&nbsp;</td>
 <td>&nbsp;</td><td>&nbsp;</td>
 </tr>         
         

 <tr>
 <td>Total Room price</td><td colspan="5" style="text-align: right;"><?php echo"$total_room_price"; ?></td>
 </tr>
 <tr>
 <td>Total Service charge</td><td colspan="5" style="text-align: right;"><?php echo"$total_service_charge"; ?></td>
 </tr>
 <tr>
 <td>Damage Claim</td><td colspan="5" style="text-align: right;"><?php echo"($damage_name) $damage_amount"; ?></td>
 </tr>         
 
 <tr>
 <td>रू./Rs.</td><td colspan="5" style="text-align: right;"><?php 
 $net_total = $total_amount+$damage_amount;
 echo"$net_total"; ?></td>
 </tr>   
 
 <tr><td colspan="6">&nbsp;</td></tr>
 <tr>
 <td colspan="6" style="text-align: right;">
 अतिथि गृह, बेंगलूरु/Guest House, Bengaluru.
 </td>
 </tr>      
                
                
                 </tbody>
              </table>
              
              </div>
              
              <center>
              
              <a href="#" onclick="printDiv('printableArea')"><i class="fa fa-print fa-lg" aria-hidden="true"></i></a>
              </center>
              
</div>
</center>



 
              
               
            
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
     
      
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    
    
    


    </div>
<br>
<br>
<br>

 <script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function() {
    j('#example').DataTable( {
        dom: 'Bfrtip',
	"ordering": false,
	"pageLength": 50,
        buttons: [
            'copy', 'csv', 'excel', 'print'
        ]
    } );
} );
</script>


  @include('layouts/footer_public')
  
