<?php
//echo"$id view";
?>

@include('layouts.app')

              <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">


<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
 




 
      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Guest House Booking Report</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  @if(Session:: has('message'))
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> {{ Session::get('message') }} </strong>
        @yield('content')
    </div>
@endif 

 
                        {{ csrf_field() }}
                        
                        <div class="table-responsive">
                        <table id="example" class="display" style="width:100%">
                <thead>
               

 <tr>
 <th>Booking ID</th>
 <th>Name</th>
 <th>Email-ID</th>
 <th>Mobile Number</th>
 <th>Check-in Date</th>
 <th>Check-out Date</th>
 
 <th>No of Days</th>
 <th>No of Rooms</th>
 <th>Room Number</th>
 <th>Total Room price</th>
 <th>Total Service charge</th>
 <th>Damage Claim</th>
 <th>Total Amount</th>
 </tr>
 </thead>
                <tbody>
@foreach($results as $value)
        <tr>
        
        <td>{{$value->id_booking }}</td>
        <td>{{$value->name }}</td>
        <td>{{$value->email_id }}</td>
        <td>{{$value->mobile_no }}</td>
        <td>{{$value->ci_date }}</td>
        <td>{{$value->co_date }}</td>
        <?php 
        include 'conn.php';
        $id = $value->id_booking;
            $query="Select * from g_booking where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $days_count=$row['days_count'];
               $total_room_price=$row['total_room_price'];
               $total_service_charge=$row['total_service_charge'];
               $damage_claim=$row['damage_claim'];
               $total_amount=$row['total_amount'];
               $no_rooms=$row['no_rooms'];
           }
           
           /* $query2="Select * from g_booking_manager where id='$id'";
           $stmt2= $conn->query($query2);
           while($row2 = $stmt2->fetch())
           {
               $days_count=$row2['days_count'];
               $total_room_price=$row2['total_room_price'];
           } */
           
               ?>
        <td><?php echo"$days_count"; ?></td>
        <td><?php echo"$no_rooms"; ?></td>
        <td>
        <?php 
        $room_exp = $value->room_no;
        
        $ro_exp = explode("|", $room_exp);
        
        echo"$ro_exp[0]  $ro_exp[1]";
        ?>
        </td>
        <td><?php echo"$total_room_price"; ?></td>
        <td><?php echo"$total_service_charge"; ?></td>
        <td><?php echo"$damage_claim"; ?></td>
        <td><?php echo"$total_amount"; ?></td>
        
        
        </tr>
        
         @endforeach
                 </tbody>
              </table>
              
              </div>

</div>


    
                 <script type="text/javascript">
var j = jQuery.noConflict();
j(document).ready(function() {
    j('#example').DataTable( {
        dom: 'Bfrtip',
	"ordering": false,
	"pageLength": 50,
        buttons: [
            'pdf', 'print'
        ]
    } );
} );
</script>


  @include('layouts/footer_public')
  
 