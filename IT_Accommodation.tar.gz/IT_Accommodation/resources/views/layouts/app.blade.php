<!DOCTYPE html>
<html>

<head>
    <title>Guest House Booking</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="{{ secure_asset('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ secure_asset('https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css') }}">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="{{ secure_asset('css_3/normalize.css') }}">
    <link rel="stylesheet" href="{{ secure_asset('fonts_3/fonts.css?id=122') }}">
    <!--  <link rel="stylesheet" href="css_3/owl.carousel.css"> -->
    <link rel="stylesheet" type="text/css" href="{{ secure_asset('https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css') }}">
    <link rel="stylesheet" href="{{ secure_asset('https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css') }}">
    <link rel="stylesheet" href="{{ secure_asset('css_3/custom.css?id=122') }}">
    <link rel="stylesheet" href="{{ secure_asset('css_3/animate.css?id=122') }}">
    <link href="{{ secure_asset('https://www.jqueryscript.net/css_3/jquerysctipttop.css') }}" rel="stylesheet" type="text/css">
    <script src="{{ secure_asset('https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js') }}"></script>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <style>
        .cus-emp-login {
        color: #36c !important;
        font-family: nova-bold;
        line-height: 22px;
        text-align: left;
        text-decoration: none;
        font-size:22px;
        }
        /*Menu Css*/
        .cus-ul {
        background: #3366cc;
        }
        .cus-ul li> a.nav-link {
        color: #fff !important;
        font-size: 14px;
        font-family: Nova-semibold;
        padding: 5px 7px !important;
        }
        .cus-ul li> a.nav-link:hover,.cus-ul li.active> a.nav-link{background:#336;}
        .cus-ul:before {
        border-bottom: 31px solid #336;
        border-left: 80px solid #0000;
        border-right: 0px solid #0000;
        width: 20px;
        content: "";
        background: #f8f9fa;
        }
        </style>
        

        
</head>

<body>
    <header>
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-md navbar-light bg-light pr-0">
                <a class="my-auto navbar-brand" href="#"><img src="{{ secure_asset('images_3/site-logo.png') }}" alt="ka-goa-logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse w-100 flex-md-column" id="navbarCollapse">
                    <div class="navbar-text ml-auto">
                        <div class="center d-inline pr-3"><a href="login" type="text" class="btn btn-link cus-emp-login text-uppercase">
                        
                                <p class="d-flex m-0 p-0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                </p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            </a></div>
                    </div>
                    <ul class="mb-xl-n3 ml-auto navbar-nav small cus-ul pr-3">
                        <li class="nav-item active">
                            <a class="nav-link" href="{{ secure_asset('home') }}"><i class="fa fa-home" aria-hidden="true"></i></a>
                        </li>
                        
						
						
						
						<!-- <li class="nav-item">
                            <a class="nav-link" href="forms_download_public" id="navbardrop">
                                Dashboard
                            </a>
                        </li> -->
                        <?php
                            include 'conn.php';
                            $admin_email = Auth::user()->email;
                            //echo"$admin_email";
                            $query1="Select * from users where email='$admin_email'";
                            $stmt1= $conn->query($query1);
                            while($row1 = $stmt1->fetch())
                            {
                                $role=$row1['role'];
                            }
                            
                            if($role == "admin")
                            {
                            ?>
                            
                        <li class="nav-item">
                            <a class="nav-link" href="{{ secure_asset('Referral_booking') }}" id="navbardrop">
                               Referral Booking
                            </a>
                        </li>    
                            
                            <li class="nav-item">
                            <a class="nav-link" href="{{ secure_asset('room_items') }}" id="navbardrop">
                               Add Room Items
                            </a>
                        </li>
                            <?php 
                            }
                            ?>
                            
                            <?php
                            if($role == "admin")
                            {
                            ?>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ secure_asset('manager_reports') }}" id="navbardrop">
                               Reports
                            </a>
                        </li>
                        <?php 
                            }
                            else
                            {
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ secure_asset('manager_reports') }}" id="navbardrop">
                               Reports
                            </a>
                        </li>
                        
                        <?php 
                            }
                        ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                               {{ Auth::user()->name }} Profile
                            </a>
                            <div class="dropdown-menu">
                            		<!-- <a class="dropdown-item" href="{{ route('register') }}">Register</a> -->
                                <a class="dropdown-item" href="images_public">Change Password</a>
                                
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>
                                        
                                        
                                         <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
								
                                
                            </div>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="forms_download_public" id="navbardrop">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        
                            </a>
                        </li>
                        
                        
                    </ul>
                </div>
            </nav>
        </div>
    </header>
