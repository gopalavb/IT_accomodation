<?php
include 'conn.php';
$admin_email = Auth::user()->email;
//echo"$admin_email";
$query1="Select * from users where email='$admin_email'";
$stmt1= $conn->query($query1);
while($row1 = $stmt1->fetch())
{
    $role=$row1['role'];
}
?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript">

        	
	function checknametwo()
        {
            var ct1=document.getElementById( "datepicker2" ).value;
            var ct11=document.getElementById( "datepicker1" ).value;
            
            if(ct1)
            {
                $.ajax({
                    type: 'post',
                    url: 'checkdata_two_to_admin.php',
                    data: {
                        date2:ct1,
                        date1:ct11,
                        
                    },
                    success: function (response) {
                        $( '#name_statustwo' ).html(response);
                        if(response=="OK")
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                });
            }
            else
            {
                $( '#name_statustwo' ).html("");
                return false;
            }
        }

</script>

<div class="container">
<br>
  <h3>Guest House Booking</h3>
  
   <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

<br>

<?php 
if($role == "admin")
{
?>


<div class="col-sm-12">
						<div class="row">
                            <div class="col-sm-5 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" readonly required>
                            </div>      
                            <div class="col-sm-5 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2" readonly required>
                            </div>
                            <div class="col-sm-2 form-group">
                                <input type='submit' name='submit' onclick="checknametwo();"  value='Check availability' >
                            </div>    
                        </div>  
                        
                      
    						<div class="row">
                            <span id="name_statustwo" style="font-weight: bold; width: 1100px;"></span>
                            </div>
                            
</div>



<h3>Pending Bookings</h3>
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Traveller Name</th>
        <th>Employee ID</th>
        <th>Email-ID</th>
        <th>Mobile Number</th>
        <th>Check-in Date</th>
        <th>Check-out Date</th>
        <th>No of Guest's</th>
        <th>No of Rooms</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
    <?php


            $query="Select * from g_booking where status='pending'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
      echo"<tr><td>$t_name</td><td>$emp_id</td><td>$email_id</td><td>$mobile_no</td><td>$ci_date</td><td>$co_date</td><td>$no_guest</td><td>$no_rooms</td>";
      echo"<td><a href='gb_view/$id'><i class='fa fa-eye'></i></td></tr>";
           }
      ?>
      
    </tbody>
  </table>
  </div>
  
  
  <h3>Approved Bookings</h3>
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Traveller Name</th>
        <th>Employee ID</th>
        <th>Email-ID</th>
        <th>Mobile Number</th>
        <th>Check-in Date</th>
        <th>Check-out Date</th>
        <th>No of Guest's</th>
        <th>No of Rooms</th>
        <th>View</th>
        <th>Cancel</th>
      </tr>
    </thead>
    <tbody>
    <?php


            $query="Select * from g_booking where status='Approve' AND id NOT IN (select id_booking from g_booking_manager)";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
      echo"<tr><td>$t_name</td><td>$emp_id</td><td>$email_id</td><td>$mobile_no</td><td>$ci_date</td><td>$co_date</td><td>$no_guest</td><td>$no_rooms</td>";
      echo"<td><a href='gb_update_gb/$id'><i class=\"fa fa-eye\" aria-hidden=\"true\"></i></td>";
      echo"<td><a href='gb_cancel/$id' onClick=\"return confirm('Are you sure do you want to Cancel this Booking ?');\"><i class=\"fa fa-times\" aria-hidden=\"true\"></i></td></tr>";
           }
      ?>
      
    </tbody>
  </table>
  </div>
</div>
<?php 
}
else if($role == "manager")
{
   // echo"hello";
?>

<h3>About to Check-IN</h3>
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Traveller Name</th>
        <th>Employee ID</th>
        <th>Email-ID</th>
        <th>Mobile Number</th>
        <th>Check-in Date</th>
        <th>Check-out Date</th>
        <th>No of Guest's</th>
        <th>No of Rooms</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $sql = "Select count(*) from g_booking where status='Approve' AND id NOT IN (select id_booking from g_booking_manager)";
    $result = $conn->prepare($sql);
    $result->execute();
    $number_of_rows = $result->fetchColumn(); 

    if($number_of_rows > 0)
    {
            $query="Select * from g_booking where status='Approve' AND id NOT IN (select id_booking from g_booking_manager)";
           $stmt= $conn->query($query);
           while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
      echo"<tr><td>$t_name</td><td>$emp_id</td><td>$email_id</td><td>$mobile_no</td><td>$ci_date</td><td>$co_date</td><td>$no_guest</td><td>$no_rooms</td>";
      echo"<td><a href='gb_view_manager/$id'><i class='fa fa-eye'></i></td></tr>";
           }
    }
    else 
    {
        echo"<tr><td colspan='9'>No Booking details found</td></tr>";
    }
      ?>
      
    </tbody>
  </table>
  </div>

<br><br>

<h3>About to Check-OUT</h3>
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Traveller Name</th>
        <th>Employee ID</th>
        <th>Email-ID</th>
        <th>Mobile Number</th>
        <th>Check-in Date</th>
        <th>Check-out Date</th>
        <th>No of Guest's</th>
        <th>No of Rooms</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
    <?php

    $cur_date = date('Y-m-d');
    //$sql1 = "select count(*) from g_booking_manager where status='check-in' AND co_date='$cur_date'";
    $sql1 = "select count(*) from g_booking_manager where status='check-in' AND co_date >= CURDATE()";
    
    $result1 = $conn->prepare($sql1);
    $result1->execute();
    $number_of_rows1 = $result1->fetchColumn(); 

    if($number_of_rows1 > 0)
    {
            $query="select * from g_booking_manager where status='check-in' AND co_date >= CURDATE() ORDER BY co_date ASC";
           $stmt= $conn->query($query);
           while($row = $stmt->fetch())
           {
               $name=$row['name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
               $id_booking=$row['id_booking'];
      echo"<tr><td>$name</td><td>$emp_id</td><td>$email_id</td><td>$mobile_no</td><td>$ci_date</td><td>$co_date</td><td>$no_guest</td><td>$no_rooms</td>";
      echo"<td><a href='co_rec_gen/$id_booking'><i class='fa fa-eye'></i></td></tr>";
           }
    }
    else 
    {
        echo"<tr><td colspan='9'>No Booking details found</td></tr>";
    }
      ?>
      
    </tbody>
  </table>
  </div>

<?php 
}
?>


</div>
<br><br><br><br>
<?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 1,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
