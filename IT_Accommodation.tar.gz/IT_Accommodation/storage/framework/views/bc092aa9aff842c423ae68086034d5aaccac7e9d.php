<?php
//echo"manager: $id";
?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>








             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 
<style>
    #my_camera{
        width: 260px;
        height: 200px;
        border: 1px solid black;
    }
	</style>




    <?php
include 'conn.php';

            $query="Select * from g_booking where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
           	   $city=$row['city'];
           	   $id_proof=$row['id_proof'];
           	   $id_number=$row['id_number'];
           	   $off_pri=$row['off_pri'];
           	   $path=$row['path'];
           	   $civil_id=$row['civil_id'];
           	   $status=$row['status'];
           	   $sel_obh=$row['sel_obh'];
           	   $self_half_text=$row['self_half_text'];
           	   $designation=$row['designation'];
           	   $adults=$row['adults'];
           	   $kids=$row['kids'];
           	   
           	   $room_type=$row['room_type'];
           	   $room_number=$row['room_number'];
           	   $ci_time=$row['ci_time'];
           	   $co_time=$row['co_time'];
           }
           
           $explo1 = explode("-", $ci_date);
           $year1 =  $explo1[0];
           $month1 =  $explo1[1];
           $date1 =  $explo1[2];
           $ci_date1 = "$date1-$month1-$year1";
           
           $explo2 = explode("-", $co_date);
           $year2 =  $explo2[0];
           $month2 =  $explo2[1];
           $date2 =  $explo2[2];
           $co_date1 = "$date2-$month2-$year2";
      ?>
      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Manager Confirm Booking</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

 <form class="form-horizontal" method="POST" action="<?php echo e(URL::asset('gb_cico_mgr')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


<input type="hidden" name="id" value="<?php echo"$id"; ?>">
<div class="col-sm-12">
                    
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <div id="my_camera"></div>
                                           <input type=button value="Take Snapshot" onClick="take_snapshot()">
                            </div>
                            <div class="col-sm-6 form-group">
                               <div id="results" ></div>
											<input type="hidden" name="imagedatas" id = 'copy_to' >
											
                            </div>
                        </div> 
                        
                        
                       <div class="row">
                       <div class="col-sm-6 form-group">
                                <label>No of Rooms</label>
                                <select name="no_rooms" class="form-control" readonly>
                                         <option value="<?php echo"$no_rooms"; ?>"><?php echo"$no_rooms"; ?></option>
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                         
                                 </select>
                            </div>
                            
                            <div class="col-sm-6 form-group">
                                <label>No of Guest's</label>
                                <select name="no_guest" class="form-control" readonly>
                                <option value="<?php echo"$no_guest"; ?>"><?php echo"$no_guest"; ?></option>
                                        <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option>
                                 </select>
                            </div>
                        </div>
                        
                        	<div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Adults</label>
                                <select name="adults" class="form-control" readonly>
                                <option value="<?php echo"$adults"; ?>"><?php echo"$adults"; ?></option>
                                      <!--   <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option> -->
                                 </select>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label>Kids</label>
                                <select name="kids" class="form-control" readonly>
                                <option value="<?php echo"$kids"; ?>"><?php echo"$kids"; ?></option>
                                      <!--   <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option> -->
                                 </select>
                            </div>  
                        </div>
                        
                       <div class="row">
                            <div class="col-sm-12 input-group control-group after-add-more">
          <input type="text" name="t_name[]" value="<?php echo"$t_name"; ?>" readonly class="form-control auto2" placeholder="Guest Name">
          <div class="input-group-btn"> 
            <button class="btn btn-success add-more" type="button"><i class="glyphicon glyphicon-plus"></i> Add</button>
          </div>
        </div>
        
        
             
                              
                        </div>
                        
                  
                  
                   <div class="row">
                   <div class="col-sm-6 form-group">
                                <label>Designation</label>
                                <input type="text" name='designation' class="form-control" value="<?php echo"$designation"; ?>" readonly required>
                            </div>
                   </div>      
                        

                        
                        <div class="row">
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" value="<?php echo"$ci_date1"; ?>" class="form-control"  readonly required>
                            </div>  
                            <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="fromtime" class="form-control" style="width: 100px;" readonly required>
                                <option value="<?php echo"$ci_time"; ?>"><?php echo"$ci_time"; ?></option>
                            <option>00:00</option>
                           <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>
							</select>
                        	</div>    
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" class="form-control" value="<?php echo"$co_date1"; ?>"  readonly required>
                            </div>  
                            <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="totime" class="form-control" style="width: 100px;" readonly required>
                                <option value="<?php echo"$co_time"; ?>"><?php echo"$co_time"; ?></option>
                            <option>00:00</option>
                            <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>

                        </select>
                            </div>
                        </div>
                        		
                        		
                        		<div class="row">
                             
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Type of Accommodation</label>
                                <select name="type_accomm" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <option value="Offical">Offical Tour</option>
                                         <option value="Private">Private</option>
                                         <option value="Other department">Offical/Officers of Other Department</option>
                                         <option value="Family">Family Members of Department Officers</option>
                                 </select>
                            </div>
                            
                        </div>
                        <?php 
                        $exp_rty = explode("|", $room_type);
                        $exp_rty1 = $exp_rty[0];
                        $exp_rty2 = $exp_rty[1];
                        
                        $query_rtype="Select * from amount_service where id='$exp_rty1'";
                        $stmt_rtype= $conn->query($query_rtype);
                        while($row_rtype = $stmt_rtype->fetch())
                        {
                            $rtype1=$row_rtype['id'];
                            $rtype_acc1 =$row_rtype['type_of_accd'];
                        }
                        
                        $query_rtype2="Select * from amount_service where id='$exp_rty2'";
                        $stmt_rtype2= $conn->query($query_rtype2);
                        while($row_rtype2 = $stmt_rtype2->fetch())
                        {
                            $rtype2=$row_rtype2['id'];
                            $rtype_acc2 =$row_rtype2['type_of_accd'];
                        }
                        
                        $exp_rno = explode("|", $room_number);
                        $exp_rno1 = $exp_rno[0];
                        $exp_rno2 = $exp_rno[1];
                        ?>
                        
                        <?php 
                        if($no_rooms == "1")
                        {
                           
                        ?>
                        <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Rooms Type</label>
                                <select name="room_type[]" class="form-control" readonly required>
                                   <option value="<?php echo"$rtype1"; ?>"><?php echo"$rtype_acc1"; ?></option>      
                                 </select>
                            </div>
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Room Number</label>
                                <!--  <input type="text" name='room_number[]' class="form-control" value="<?php echo"$exp_rno1"; ?>" readonly required> -->
                                 <select name='room_number[]' class="form-control" readonly required>
                                   <option value="<?php echo"$exp_rno1"; ?>"><?php echo"$exp_rno1"; ?></option>      
                                 </select> 
                            </div>  
                        </div>
                        <?php 
                        }
                        else if($no_rooms == "2")
                        {
                            
                        ?>
                         
                         <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font> Rooms Type</label>
                                <select name="room_type[]" class="form-control" readonly required>
                                         <option value="<?php echo"$rtype1"; ?>"><?php echo"$rtype_acc1"; ?></option>
                                 </select>
                            </div>
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Room Number</label>
                                 <!-- <input type="text" name='room_number[]' class="form-control" value="<?php echo"$exp_rno1"; ?>" readonly required> -->
                                 <select name='room_number[]' class="form-control" readonly required>
                                   <option value="<?php echo"$exp_rno1"; ?>"><?php echo"$exp_rno1"; ?></option>      
                                 </select>  
                            </div>  
                        </div>
                        
                        <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font> Rooms Type</label>
                                <select name="room_type[]" class="form-control" readonly required>
                                         <option value="<?php echo"$rtype2"; ?>"><?php echo"$rtype_acc2"; ?></option>
                                 </select>
                            </div>
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Room Number</label>
                                 <!-- <input type="text" name='room_number[]' class="form-control" value="<?php echo"$exp_rno2"; ?>" readonly required>-->
                                 <select name='room_number[]' class="form-control" readonly required>
                                   <option value="<?php echo"$exp_rno2"; ?>"><?php echo"$exp_rno2"; ?></option>      
                                 </select>
                            </div>  
                        </div>
                        <?php 
                        }
                        else
                        {
                         ?>
                         <div class="row">
                             <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Rooms Type</label>
                                <select name="room_type[]" id="drop_1" class="form-control" required>
                                         <option value="">--Select--</option>
                                         <?php 
                                         $query_rt="Select * from amount_service";
                                         $stmt_rt= $conn->query($query_rt);
                                         while($row_rt = $stmt_rt->fetch())
                                         {
                                             $id_rt=$row_rt['id'];
                                             $type_of_accd=$row_rt['type_of_accd'];
                                            echo"<option value='$id_rt'>$type_of_accd</option>";
                                         }
                                         ?>
                                 </select>
                            </div>
                            
                            <?php 
                            include 'conn.php';
                            $equery = $conn->prepare("select room_number from room_type");
                            $equery->execute();
                            
                            echo"<div class='col-sm-6 form-group'>";
                            echo"<label><font color='red'>*</font>Room Number</label>";
                            echo"<select name='room_number[]' class='form-control' required>";
                            echo "<option value=''>---Select---</option>";
                            while ($erows = $equery->fetch())
                            {
                                $room_number = $erows['room_number'];
                                
                                echo "<option value='$room_number'>$room_number</option>";
                            }
                            echo " </select></div>";
                            
                            ?> 
                        </div>
                         <?php 
                        }
                         ?> 
                        
                        <div class="row">
                            <!-- <div class="col-sm-6 form-group">
                                <label>Civil ID</label>
                                <input type="text" name='civil_id' class="form-control">
                            </div> -->      
                             <div class="col-sm-6 form-group">
                                <label>Civil Code/Employee ID</label>
                                <input type="text" name='emp_id' value="<?php echo"$emp_id"; ?>" readonly class="form-control">
                            </div>
                            <div class="col-sm-6 form-group">
                                <label>Email-ID</label>
                                <input type="email" name='email_id' class="form-control" value="<?php echo"$email_id"; ?>" readonly>
                            </div> 
                        </div>
                        
                        
                        
                         <div class="row">
                             
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" value="<?php echo"$mobile_no"; ?>" readonly pattern="[0-9]{10}" required>
                            </div> 
                            <div class="col-sm-6 form-group">
                                <label>ID Proof</label>
                                 <select name="id_proof" class="form-control" readonly>
                                  <option value="<?php echo"$id_proof"; ?>"><?php echo"$id_proof"; ?></option>
                                  <option value="Department ID">Department ID</option>
                                         <option value="Aadhaar card">Aadhaar Card</option>
                                         <option value="Permanent Account Number">Permanent Account Number</option>
                                         <option value="Driving License">Driving License</option>
                                         <!-- <option value="Others">Other's</option> -->
                                         <!-- <option value=""></option>
                                         <option value=""></option>
                                          -->
                                 </select>
                            </div>   
                        </div>
                        
                        <div class="row">
                                 
                            <div class="col-sm-6 form-group">
                                <label>ID Number</label>
                                <input type="text"  name="id_number" class="form-control" value="<?php echo"$id_number"; ?>" readonly>
                            </div> 
                            
                            <div class="col-sm-6 form-group">
                                <label></label>
                                 <select name="sel_obh" id="se_ob" class="form-control" readonly>
                                         <option value="<?php echo"$sel_obh"; ?>"><?php echo"$sel_obh"; ?></option>
                                         <option value="self">self</option>
                                         <option value="on behalf of">on behalf of</option>
                                 </select>
                            </div>
                             
                        </div>
                              
                              <div class="row">
                              
                            <div class="col-sm-6 form-group">
                            <br>
                             <?php 
                                if($sel_obh == "self")
                                {
                                ?>
                                        <?php 
                                        if($off_pri == "Offical")
                                        {
                                        ?>
                                        <input type="radio" name='off_pri' value='Offical' checked  >&nbsp;&nbsp;Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private'  >&nbsp;&nbsp;Private
                                        <?php 
                                        }
                                        else if($off_pri == "Private")
                                        {
                                            ?>
                                            <?php echo"$off_pri"; ?>
                                         <input type="radio" name='off_pri' value='Offical'  >&nbsp;&nbsp;Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private' checked  >&nbsp;&nbsp;Private   
                                            
                                            <?php 
                                        }
                                        else 
                                        {
                                        ?>
                                        <input type="radio" name='off_pri' value='Offical' >&nbsp;&nbsp;Offical
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="radio" name='off_pri' value='Private'>&nbsp;&nbsp;Private
                                        <?php 
                                        }
                                }
                                else 
                                {
                                ?>
                                      <input type="text"  name="self_half_text" value="<?php echo"$self_half_text"; ?>" class="form-control" readonly>
                                <?php 
                                }
                                ?>  
                                </div>  
                                
                                <div class="col-sm-6 form-group">
                            <?php 
                            $exp1 = explode("|",$path);
                            $exp_count = count($exp1);
                            for($i=0;$i<$exp_count;$i++)
                            {
                            ?>
                            
                            <a href="<?php echo URL::asset("attachment/$exp1[$i]"); ?>" target="_blank">Guest/Admin Uploaded documents</a><br>
                            <?php 
                            }
                            ?>
                            <br>
                                <label><font color='red'>*</font>Browse & Upload</label>
                                <input type="file" name="upload_file[]" multiple>
                            </div>   
                        </div>  
                        
                        
                        
                        
                        <div class="row">
                           
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Remarks</label>
                                <textarea rows="" cols="" name="remarks" class="form-control" required></textarea>
                            </div>      
                        </div> 
                        
                                   
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' class="btn btn-primary"  value='Submit' >
                      
                    <br><br>              
                    </div>
</form>


    </div>



  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker111" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "<?php echo e(URL::asset('images_3/calendar.gif')); ?>",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker222" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "<?php echo e(URL::asset('images_3/calendar.gif')); ?>",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>



 <!-- Webcam.min.js -->
    <script type="text/javascript" src="<?php echo e(URL::asset('webcamjs/webcam.min.js')); ?>"></script>

	<!-- Configure a few settings and attach camera -->
	<script language="JavaScript">
		Webcam.set({
			width: 260,
			height: 200,
			image_format: 'jpeg',
			jpeg_quality: 90
		});
		Webcam.attach( '#my_camera' );
	</script>
	<!-- A button for taking snaps -->
	
	<!-- Code to handle taking the snapshot and displaying it locally -->
	<script language="JavaScript">

		function take_snapshot() {
			
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				// display results in page
				document.getElementById('results').innerHTML = 
					'<img src="'+data_uri+'"/>';
				document.getElementById("copy_to").value = data_uri;
			} );
		}
	</script>
	
	
	
	<div class="copy hide" style="display:none;">
          <div class="col-sm-12 control-group input-group" style="margin-top:10px">
            <input type="text" name="t_name[]" class="form-control auto3" placeholder="Guest Name">
            <div class="input-group-btn"> 
              <button class="btn btn-danger remove" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
            </div>
          </div>
        </div> 
       
        
	<script type="text/javascript">


    $(document).ready(function() {
	$(".add-more").click(function(){ 
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });
	$("body").on("click",".remove",function(){ 
          $(this).parents(".control-group").remove();
      });


    });


</script>