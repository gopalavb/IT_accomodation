<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 

<div class="container">
<br>
  <h3>Guest House Booking Manager</h3>
  
   <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

<br>
<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr style="background-color: #69c; color:#000;">
        <th>Traveller Name</th>
        <th>Employee ID</th>
        <th>Email-ID</th>
        <th>Mobile Number</th>
        <th>Check-in Date</th>
        <th>Check-out Date</th>
        <th>No of Guest's</th>
        <th>No of Rooms</th>
        <th>View</th>
      </tr>
    </thead>
    <tbody>
    <?php
include 'conn.php';

            $query="Select * from g_booking where status='pending'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $no_guest=$row['no_guest'];
               $no_rooms=$row['no_rooms'];
           	   $id=$row['id'];
      echo"<tr><td>$t_name</td><td>$emp_id</td><td>$email_id</td><td>$mobile_no</td><td>$ci_date</td><td>$co_date</td><td>$no_guest</td><td>$no_rooms</td>";
      echo"<td><a href='gb_view/$id'><i class='fa fa-eye'></i></td></tr>";
           }
      ?>
      
    </tbody>
  </table>
  </div>
</div>





<br><br><br><br>


  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>