<!DOCTYPE html>
<html>

<head>
    <title>The Official Income Tax Bengaluru</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css_3/normalize.css">
    <link rel="stylesheet" href="fonts_3/fonts.css?id=122">
    <!--  <link rel="stylesheet" href="css_3/owl.carousel.css"> -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="css_3/custom.css?id=122">
    <link rel="stylesheet" href="css_3/animate.css?id=122">
    <link href="https://www.jqueryscript.net/css_3/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <style>
        .cus-emp-login {
        color: #36c !important;
        font-family: nova-bold;
        line-height: 22px;
        text-align: left;
        text-decoration: none;
        font-size:22px;
        }
        /*Menu Css*/
        .cus-ul {
        background: #3366cc;
        }
        .cus-ul li> a.nav-link {
        color: #fff !important;
        font-size: 14px;
        font-family: Nova-semibold;
        padding: 5px 7px !important;
        }
        .cus-ul li> a.nav-link:hover,.cus-ul li.active> a.nav-link{background:#336;}
        .cus-ul:before {
        border-bottom: 31px solid #336;
        border-left: 80px solid #0000;
        border-right: 0px solid #0000;
        width: 20px;
        content: "";
        background: #f8f9fa;
        }
        </style>
</head>

<body>
    <header>
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-md navbar-light bg-light pr-0">
                <a class="my-auto navbar-brand" href="https://incometaxbengaluru.org/"><img src="images_3/site-logo.png" alt="ka-goa-logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
               
            </nav>
        </div>
    </header>


<div class="container minheight">
<br>
   <h3 style="margin-left: 14px;">IT Accommodation Login</h3>
<br>


  <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 


      <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>


	</div>
	
<br><br><br>

  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
</body>
</html>



