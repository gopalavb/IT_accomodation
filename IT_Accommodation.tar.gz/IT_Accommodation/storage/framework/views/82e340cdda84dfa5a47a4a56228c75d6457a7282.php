<!DOCTYPE html>
<html>

<head>
    <title>I T Guest House Booking</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css_3/normalize.css">
    <link rel="stylesheet" href="fonts_3/fonts.css?id=122">
    <!--  <link rel="stylesheet" href="css_3/owl.carousel.css"> -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="css_3/custom.css?id=122">
    <link rel="stylesheet" href="css_3/animate.css?id=122">
    <link href="https://www.jqueryscript.net/css_3/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <style>
        .cus-emp-login {
        color: #36c !important;
        font-family: nova-bold;
        line-height: 22px;
        text-align: left;
        text-decoration: none;
        font-size:22px;
        }
        /*Menu Css*/
        .cus-ul {
        background: #3366cc;
        }
        .cus-ul li> a.nav-link {
        color: #fff !important;
        font-size: 14px;
        font-family: Nova-semibold;
        padding: 5px 7px !important;
        }
        .cus-ul li> a.nav-link:hover,.cus-ul li.active> a.nav-link{background:#336;}
        .cus-ul:before {
        border-bottom: 31px solid #336;
        border-left: 80px solid #0000;
        border-right: 0px solid #0000;
        width: 20px;
        content: "";
        background: #f8f9fa;
        }
        </style>
        
                <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
<script>
        $(document).ready(function (){
            $("#se_ob").change(function() {
                if ($(this).val() == "self") {
                        $("#hi1").show();
                        $("#hi2").hide();
                
                    } 
                else if ($(this).val() == "on behalf of") {
                    $("#hi1").hide();
                    $("#hi2").show();
            
                }
                });});
    </script>
    
<style type="text/css">
       form {
  width: 100%;
  max-width: 980px;
  margin: 0 auto;
}

.scroll-box {
  overflow-y: scroll;
  width: 990px;
  height: 100px;
  margin-left: 0px;
  border: 1px;
}
       </style>
       
        <script type="text/javascript" src="./js/jquery.min.js"></script>   
   <script type="text/javascript">
$(document).ready(function() {
	$('#wait_1').hide();
	$('#drop_1').change(function(){
	  $('#wait_1').show();
	  $('#result_1').hide();
      $.get("func8.php", {
		func: "drop_1",
		drop_var: $('#drop_1').val()
      }, function(response){
        $('#result_1').fadeOut();
        setTimeout("finishAjax('result_1', '"+escape(response)+"')", 400);
      });
    	return false;
	});
});

function finishAjax(id, response) {
  $('#wait_2').hide();
  $('#'+id).html(unescape(response));
  $('#'+id).fadeIn();
}
</script>    



<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript">

        	
	function checknametwo()
        {
            var ct1=document.getElementById( "datepicker2" ).value;
            var ct11=document.getElementById( "datepicker1" ).value;
            
            if(ct1)
            {
                $.ajax({
                    type: 'post',
                    url: 'checkdata_differ_five.php',
                    data: {
                        date2:ct1,
                        date1:ct11,
                        
                    },
                    success: function (response) {
                        $( '#name_statustwo' ).html(response);
                        if(response=="OK")
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                });
            }
            else
            {
                $( '#name_statustwo' ).html("");
                return false;
            }
        }

</script>

</head>

<body>
    <header>
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-md navbar-light bg-light pr-0">
                <a class="my-auto navbar-brand" href="https://incometaxbengaluru.org/"><img src="images_3/site-logo.png" alt="ka-goa-logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
               
            </nav>
        </div>
    </header>


<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">I T Guest House Booking</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

 <form class="form-horizontal" method="POST" action="gb_public" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


<div class="col-sm-12">
                    
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>City</label>
                                 <select name="city" class="form-control" required>
                                         <option value="">---Select---</option>
                                         <option value="Bengaluru">Bengaluru</option>
                                         <!-- <option value="Goa">Goa</option> -->
                                 </select>
                            </div>  
                            
                               
                        </div>
                        
                        <span id="name_statustwo" style="font-weight: bold; width: 1100px;"></span>
                        
                        <div class="row">
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" readonly required>
                                </div>
                                <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="fromtime" class="form-control" style="width: 100px;" required>
                            <option>00:00</option>
                           <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>


                        </select>
                        
                            </div>      
                            <div class="col-sm-4 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2" onchange="checknametwo();" readonly required>
                                </div>
                                <div class="col-sm-2 form-group">
                                <label><font color='red'>*</font>Time</label>
                                <select name="totime" class="form-control" style="width: 100px;" required>
                            <option>00:00</option>
                            <option>02:00</option>
                            <option>04:00</option>
                            <option>06:00</option>
                            <option>08:00</option>
                            <option>10:00</option>
                            <option>12:00</option>
                            <option>14:00</option>
                            <option>16:00</option>
                            <option>18:00</option>
                            <option>20:00</option>
                            <option>22:00</option>

                        </select>
                            </div>  
                        </div>  
                        
                        <div class="row">
                        <h5 style="margin-left: 14px;"> Check-Out Terms & Conditions</h5>
                         <div class="scroll-box" style="border-style: solid; border-radius: 5px; padding: 20px; border-color: blue;">
  
    <b>
    "The Guests/Travelers are requested to intimate the date of check-out correctly since other guests would have their bookings and hence this field is MANDATORY. Please note that early check-out can be done while late checkouts are not permitted so as to not cause inconvenience for other guests".
  </b> 
    
    <br>
    <input type="checkbox" name="accept" value="accept" required>  I Agree Terms & Conditions
    <p>
    &nbsp;&nbsp;&nbsp;
    </p>
    </div> 
                        </div>
                          
                        
                        
                        <div class="row">
                            <!-- <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>No of Guests</label>
                                <select name="no_guest" class="form-control" required>
                                         <option value="">---Select---</option>
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                         <option value="3">3</option>
                                         <option value="4">4</option>
                                 </select>
                            </div> -->      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>No of Rooms</label>
                                <select name="no_rooms"  id="drop_1" class="form-control" required>
                                         <option value="">---Select---</option>
                                         <option value="1">1</option>
                                         <option value="2">2</option>
                                 </select>
                            </div> 
                            
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Traveller Name</label>
                                <input type="text" name='t_name' class="form-control" required>
                            </div>
                             
                         </div> 
                        
                        <span id="result_1" style="display: none; width: 1000px;"></span>
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Designation</label>
                                <input type="text" name='designation' class="form-control" required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Civil Code/Employee ID</label>
                                <input type="text" name='emp_id' class="form-control" required>
                            </div>  
                        </div>
                        
                        <div class="row">
                           <!--  <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Civil Code</label>
                                <input type="text" name='civil_id' class="form-control">
                            </div>      --> 
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Email-ID</label>
                                <input type="email" name='email_id' class="form-control" required>
                            </div>  
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" pattern="[0-9]{10}" required>
                            </div> 
                        </div>
                        
                        
                        
                        
                    					
                    					<div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>ID Proof</label>
                                 <select name="id_proof" class="form-control" required>
                                         <option value="">---Select---</option>
                                         <option value="Department ID">Department ID</option>
                                         <option value="Aadhaar card">Aadhaar Card</option>
                                         <option value="Permanent Account Number">Permanent Account Number</option>
                                         <option value="Driving License">Driving License</option>
                                         <!-- 
                                         
                                         <option value="Others">Other's</option> -->
                                         <!-- <option value=""></option>
                                         <option value=""></option>
                                          -->
                                 </select>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>ID Number</label>
                                <input type="text"  name="id_number" class="form-control" required>
                            </div>  
                        </div>
                        
                        <div class="row">
                              
                              <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font></label>
                                 <select name="sel_obh" id="se_ob" class="form-control" required>
                                         <option value="">---Select---</option>
                                         <option value="self">self</option>
                                         <option value="on behalf of">on behalf of</option>
                                 </select>
                            </div>
                            <div class="col-sm-6 form-group">
                                <br>
                                <div id="hi1" style="display: none;">
                                <input type="radio" name='off_pri' value='Offical'>&nbsp;&nbsp;Offical
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="radio" name='off_pri' value='Private'>&nbsp;&nbsp;Private
                               </div>
                                <div id="hi2" style="display: none;">
                                <input type="text"  name="self_half_text" class="form-control">
                                </div>
                            </div>      
                        </div>
                    		
                    		
                    		
                    		 <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Documents Browse & Upload</label>
                                <input type="file" name="upload_file[]" multiple required>
                            </div>      
                              
                        </div>			
                                            
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' name='submit' class="btn btn-primary"  value='Submit' >
                       
                    <br><br>              
                    </div>
</form>


    </div>

  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 3,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 4,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
    
</body>
</html>



