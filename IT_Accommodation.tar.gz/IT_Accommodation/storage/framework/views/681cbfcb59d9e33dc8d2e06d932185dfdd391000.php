<?php
//echo"$id view";
?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

             <style>
        #datepicker1 {
            width: 94%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;

        }

        #datepicker2 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
        
         #datepicker3 {

            width: 93%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;


        }
</style>
 



   
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Referral Booking</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

 <form class="form-horizontal" method="POST" action="<?php echo e(URL::asset('reff_book')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


<input type="hidden" name="id" value="<?php echo"$id"; ?>">
<input type="hidden" name="path_names" value="<?php echo"$path"; ?>">
<div class="col-sm-12">
                    
                        
                        
                        <div class="row">
                           
                                <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Guest Name</label>
                                <input type="text" name='t_name' class="form-control" required>
                           
                            </div>  
                              <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Guest Mobile Number</label>
                                <input type="text" name="mobile_no" class="form-control" pattern="[0-9]{10}" required>
                            </div> 
                               
                        </div>
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" readonly required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2" readonly required>
                            </div>  
                        </div>  
                        
                        
                        
                        <div class="row">
                          <!--   <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Referred by</label>
                                <input type="text" name='reffer_by' class="form-control" required>
                            </div> -->
                            
                        </div>
                           
                        
                        <div class="row">
                            <div class="col-sm-12 form-group">
                                <label>Admin Remarks</label>
                                
                                <textarea rows="" cols="" name="remarks" class="form-control"></textarea>
                            </div>      
                           </div>
                           <div class="row">
                           <div class="col-sm-6 form-group">
                               
                                <input type="radio" name='off_pri' value='Offical'>&nbsp;&nbsp;Offical
                                &nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="radio" name='off_pri' value='Private'>&nbsp;&nbsp;Private
                               
                            </div> 
                            
                            <div class="col-sm-6 form-group">
                                <label>Browse & Upload</label>
                                <input type="file" name="upload_file[]" multiple>
                            </div> 
                              
                        </div>	
                        
                         
                                            
                   
                    <!-- <button type="button" class="btn btn-success">Submit</button> -->  
                    <input type='submit' name='Submit' class="btn btn-primary"  value='Submit' >
                   
                    <br><br>              
                    </div>
</form>


    </div>



  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


<!-- <link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="jquery-1.12.4.js"></script>
<script src="jquery-ui.js"></script>
 -->

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 0,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "<?php echo e(URL::asset('images_3/calendar.gif')); ?>",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 1,
            maxDate : 60,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "<?php echo e(URL::asset('images_3/calendar.gif')); ?>",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>