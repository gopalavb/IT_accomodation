<?php
//echo"$id";
?>
<?php
//echo"$id";
?>
<?php
//echo"manager: $id";
?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php
include 'conn.php';
echo"$id";
            $query="Select * from g_booking where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $t_name=$row['t_name'];
               $emp_id=$row['emp_id'];
               $email_id=$row['email_id'];
               $mobile_no=$row['mobile_no'];
               $ci_date=$row['ci_date'];
               $co_date=$row['co_date'];
               $id=$row['id'];
           	   $civil_id=$row['civil_id'];
           	   $no_rooms=$row['no_rooms'];
           	   
           	   
      
           }
           
           $explo1 = explode("-", $ci_date);
           $year1 =  $explo1[0];
           $month1 =  $explo1[1];
           $date1 =  $explo1[2];
           $ci_date1 = "$date1-$month1-$year1";
           
           $explo2 = explode("-", $co_date);
           $year2 =  $explo2[0];
           $month2 =  $explo2[1];
           $date2 =  $explo2[2];
           $co_date1 = "$date2-$month2-$year2";
           
           
           $query2="Select * from g_booking_manager where id_booking='$id'";
           $stmt2= $conn->query($query2);
           while($row2 = $stmt2->fetch())
           {
               $room_type=$row2['room_type'];
               $room_no=$row2['room_no'];
           }
           
           $query3="Select * from checkout_bill_temp where id_booking ='$id'";
           $stmt3= $conn->query($query3);
           while($row3 = $stmt3->fetch())
           {
               $days_count=$row3['days_count'];
               $total_room_pri=$row3['total_room_pri'];
               $total_ser_cha=$row3['total_ser_cha'];
               $dam_cla=$row3['dam_cla'];
               $dam_cla_amount=$row3['dam_cla_amount'];
               $total_amount=$row3['total_amount'];
           }
           
           $query11="Select * from room_item where id ='$dam_cla'";
           $stmt11= $conn->query($query11);
           while($row11 = $stmt11->fetch())
           {
               $item_name=$row11['name'];
           }
           
      ?>
      
    

<div class="container minheight">

<section id="main-content">
      <section class="wrapper">
        <!-- <h3><i class="fa fa-angle-right"></i> Form Components</h3> -->
        <!-- BASIC FORM ELELEMNTS -->
        
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              
               

<center>
<div class="table-responsive">




<table class="table table-striped" style="width: 1000px;">
                <thead>
  <tr><th colspan="6" style="text-align: center;">
  आयकर विभाग / INCOME TAX DEPARTMENT
 <br>
  अतिथि गृह / GUEST HOUSE
 <br>
  <font size="2"> सं.2, आयकर कॉलोनी, इंफैन्ट्री रोड, बेंगलूरु – 560001
 <br>
 No.2, Income Tax Colony, Infantry Road, Bengaluru – 560001.
 <br>
 फोन/Ph. 080-22206978, 22206256, 22206240
 </font>
 </th></tr>
              
 </thead>
                <tbody>
                
<tr>
 <td>रसीद सं./Receipt No.:</td><td></td>
 <td>&nbsp;&nbsp;&nbsp;</td><td>&nbsp;&nbsp;&nbsp;</td>
 <td>दिनांक/Date:</td><td><?php echo"$co_date1"; ?></td>
 
 </tr> 
                 
 <tr>
 <td>श्री/श्रीमती/Shri/Smt</td><td><?php echo"$t_name"; ?></td>
 <td>Civil Code/Employee ID</td><td><?php echo"$emp_id"; ?></td>
 <td>Mobile Number</td><td><?php echo"$mobile_no"; ?></td>
 
 </tr>        
      
<tr>
<td>Check-in Date</td><td><?php echo"$ci_date1"; ?></td>
 <td>Check-out Date</td><td><?php echo"$co_date1"; ?></td>
 <td>No of Rooms</td><td><?php echo"$no_rooms"; ?></td>

 </tr>
 <?php 
 $exp_roo = explode("|", $room_type);
 $exp_r1 = $exp_roo[0];
 $exp_r2 = $exp_roo[1];


$exp_rono = explode("|", $room_no);
$exp_rn1 = $exp_rono[0];
$exp_rn2 = $exp_rono[1];




?>
 <tr>
  <td>Rooms Type</td><td><?php 
  //echo"$exp_r1   $exp_r2";
  $query4="Select * from amount_service where id='$exp_r1'";
  $stmt4= $conn->query($query4);
  while($row4 = $stmt4->fetch())
  {
      $type_of_accd1 =$row4['type_of_accd'];
  }
  $query5="Select * from amount_service where id='$exp_r2'";
  $stmt5= $conn->query($query5);
  while($row5 = $stmt5->fetch())
  {
      $type_of_accd2 =$row5['type_of_accd'];
  }
  
  echo"$type_of_accd1 <br>  $type_of_accd2";
  
  ?></td>
 <td>Room Number</td><td><?php echo"$exp_rn1 <br> $exp_rn2"; ?></td>
 <td></td><td></td>
 </tr>
 
 <tr>
 <td>&nbsp;</td><td>&nbsp;</td>
 <td>&nbsp;</td><td>&nbsp;</td>
 <td>&nbsp;</td><td>&nbsp;</td>
 </tr>         
         

 <tr>
 <td>Total Room price</td><td colspan="5" style="text-align: right;"><?php echo"$total_room_pri"; ?></td>
 </tr>
 <tr>
 <td>Total Service charge</td><td colspan="5" style="text-align: right;"><?php echo"$total_ser_cha"; ?></td>
 </tr>
 <tr>
 <td>Damage Claim</td><td colspan="5" style="text-align: right;"><?php echo"($item_name) $dam_cla_amount"; ?></td>
 </tr>         
 
 <tr>
 <td>रू./Rs.</td><td colspan="5" style="text-align: right;"><?php 

 echo"$total_amount"; ?></td>
 </tr>  
 <tr><td colspan="6">&nbsp;</td></tr>
 <tr>
 <td colspan="6" style="text-align: right;">
 अतिथि गृह, बेंगलूरु/Guest House, Bengaluru.
 </td>
 </tr>      
                
                
                 </tbody>
              </table>
              
 <!-- <input type='submit' name='submit' class="btn btn-primary"  value='Cancel' >
 
 <input type='submit' name='submit' class="btn btn-primary"  value='Proceed' > -->     
 
 <a href="co_rec_gen_cancel/<?php echo"$id"; ?>" class="btn btn-primary">Cancel</a>
 &nbsp;&nbsp;&nbsp;&nbsp;
 <a href="final_submit/<?php echo"$id"; ?>" class="btn btn-primary">Proceed & Print</a>
        
              
</div>




 
              
               
            
            </div>
          </div>
          <!-- col-lg-12-->
        </div>
     
      
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    
    
    


    </div>
<br>
<br>
<br>




  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
