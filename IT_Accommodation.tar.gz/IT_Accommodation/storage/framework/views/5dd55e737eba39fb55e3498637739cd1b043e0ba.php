<?php
//echo"$id";
?>
<?php
//echo"$id view";
?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



 <?php

    include 'conn.php';

            $query="Select * from room_item where id='$id'";
           $stmt= $conn->query($query);
            while($row = $stmt->fetch())
           {
               $name=$row['name'];
               $amount=$row['amount'];
               
               $id=$row['id'];
           }
               ?>

      
    

<div class="container minheight">
<br>

   <h3 style="margin-left: 14px;">Add Room Item</h3>
   <font color="red" style="float: right; margin-right: 30px;">* Required</font>
<br>

  <?php if(Session:: has('message')): ?>
  <div class="alert alert-success">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">�</button>
       <strong> <?php echo e(Session::get('message')); ?> </strong>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php endif; ?> 

 <form class="form-horizontal" method="POST" action="<?php echo e(URL::asset('update_item')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

<input type="hidden" name="id" value="<?php echo"$id"; ?>">

<div class="col-sm-12">
                    
                        
                        
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Name</label>
                                <input type="text" name='name' class="form-control" value="<?php echo"$name"; ?>" required>
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label><font color='red'>*</font>Amount</label>
                                <input type="text" name='amount' class="form-control" value="<?php echo"$amount"; ?>" required>
                            </div>  
                        </div>
                        
                   
                    <input type='submit' name='Submit' class="btn btn-primary"  value='Update' >
                      
              
</div>             
                    </div>



    <br><br>



  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
