 <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8">
                    <div class="widget clearfix">
                        
                        <p> Copyright � Income Tax Department, Karnataka & Goa | All Rights Reserved. </p>

                    </div><!-- end clearfix -->
                </div><!-- end col -->
               
               
            </div><!-- end row -->
        </div><!-- end container -->
    </footer>
    <div class="copyrights">
        <div class="container">
            
            <div class="row">
                <div class="col-12 disclaimer mt-2">Disclaimer: The contents of this website should not be construed as an exhaustive statement of law. In case of doubt, reference should always be made to the relevant provisions of the Direct Tax Laws and Rules and where necessary, notifications issued from time to time. Content provided by Income Tax Department, Bangalore. For any clarification regarding content, please contact the PRO, Income Tax Department, Bangalore.</div>
            </div>
        </div><!-- end container -->
    </div>
    <!--  <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script> 
                                                                        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
    <!-- <script src='js_3/owl.carousel.js'></script> -->
    <script src="<?php echo e(secure_asset('https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(secure_asset('https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js')); ?>" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="<?php echo e(secure_asset('https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js')); ?>" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <!-- ALL PLUGINS -->
    <script src="<?php echo e(secure_asset('js_3/custom.js')); ?>"></script>
    <script src="<?php echo e(secure_asset('js_3/jquery.scrollbox.js')); ?>"></script>
</body>

</html>
