<!DOCTYPE html>
<html>

<head>
    <title>Guest House Booking</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- normalize CSS
        ============================================ -->
    <link rel="stylesheet" href="css_3/normalize.css">
    <link rel="stylesheet" href="fonts_3/fonts.css?id=122">
    <!--  <link rel="stylesheet" href="css_3/owl.carousel.css"> -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="css_3/custom.css?id=122">
    <link rel="stylesheet" href="css_3/animate.css?id=122">
    <link href="https://www.jqueryscript.net/css_3/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <style>
        .cus-emp-login {
        color: #36c !important;
        font-family: nova-bold;
        line-height: 22px;
        text-align: left;
        text-decoration: none;
        font-size:22px;
        }
        /*Menu Css*/
        .cus-ul {
        background: #3366cc;
        }
        .cus-ul li> a.nav-link {
        color: #fff !important;
        font-size: 14px;
        font-family: Nova-semibold;
        padding: 5px 7px !important;
        }
        .cus-ul li> a.nav-link:hover,.cus-ul li.active> a.nav-link{background:#336;}
        .cus-ul:before {
        border-bottom: 31px solid #336;
        border-left: 80px solid #0000;
        border-right: 0px solid #0000;
        width: 20px;
        content: "";
        background: #f8f9fa;
        }
        </style>
       
       <style type="text/css">
       form {
  width: 100%;
  max-width: 980px;
  margin: 0 auto;
}

.scroll-box {
  overflow-y: scroll;
  width: 1100px;
  height: 200px;
  margin-left: -55px;
  border: 1px;
}
       </style> 
       
          <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript">

        	
	function checknametwo()
        {
            var ct1=document.getElementById( "datepicker2" ).value;
            var ct11=document.getElementById( "datepicker1" ).value;
            
            if(ct1)
            {
                $.ajax({
                    type: 'post',
                    url: 'checkdata_two_to.php',
                    data: {
                        date2:ct1,
                        date1:ct11,
                        
                    },
                    success: function (response) {
                        $( '#name_statustwo' ).html(response);
                        if(response=="OK")
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                });
            }
            else
            {
                $( '#name_statustwo' ).html("");
                return false;
            }
        }

</script>

</head>

<body>
    <header>
        <div class="container-fluid p-0">
            <nav class="navbar navbar-expand-md navbar-light bg-light pr-0">
                <a class="my-auto navbar-brand" href="https://incometaxbengaluru.org/"><img src="images_3/site-logo2.png" alt="ka-goa-logo"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
               
            </nav>
        </div>
    </header>


<div class="container minheight">
<br>
   <h3 style="margin-left: 14px;">Guest House Booking</h3>
<br>

<div class="col-sm-12">
						<div class="row">
                            <div class="col-sm-5 form-group">
                                <label><font color='red'>*</font>Check-in Date</label>
                                <input type="text" name="ci_date" id="datepicker1" readonly required>
                            </div>      
                            <div class="col-sm-5 form-group">
                                <label><font color='red'>*</font>Check-out Date</label>
                                <input type="text" name="co_date" id="datepicker2" readonly required>
                            </div>
                            <div class="col-sm-2 form-group">
                                <input type='submit' name='submit' onclick="checknametwo();"  value='Check availability' >
                            </div>    
                        </div>  
                        
                      
    						<div class="row">
                            <span id="name_statustwo" style="font-weight: bold; width: 1100px;"></span>
                            </div>
                            
</div>



    

 <h5 style="margin-left: 14px;">Terms & Conditions</h5>
 <form class="form-horizontal" method="POST" action="gb_public_second" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <div class="scroll-box" style="border-style: solid; border-radius: 5px; padding: 20px; border-color: blue;">
  
   <ul>
   <li>
   Bookings shall be accepted within 30 days in advance
   </li>
   <li>
    The O/o PRCCIT has the right to reject/cancel any bookings before check-in of the guest based on urgent requirement.
    </li>
    <li>
    Maximum permissible days for the user are 5 days per month.  
    </li>
    <li>
    Maximum number of times that user can book are 2 per month.
    </li>
    <li>
    Maximum Guests allowed are 2 adults & 2 kids (aged should be less than 10 years) per room. One extra mattresses would be provided on request basis at extra cost.
    </li>
    <li>
    Alteration of dates or postponement of bookings are not permitted after acceptance of booking request
    </li>
    <li>
    Person visiting as a guest has to produce photocopy of ID card of the employee at the time of check-in
    </li>
     <li>
    The Guests/Travelers are requested to intimate the date of check-out correctly since other guests would have their bookings and hence this field is MANDATORY. Please note that early check-out can be done while late checkouts are not permitted. Please do not cause inconvenience for other guests.
    </li>
     <li>
    2 PM Check-In and 12 Noon Check-Out
    </li>
    <li>
    Room will be cancelled without any prior notice if the guest doesn't checkin within 24 hours of check-in date - Applicable for stay beyond 1 day. 
    </li>
    <li>
    Any damages are fined extra
    </li>
    <li>Guest should carry the ID Proof while checking in </li>
    <li>Lockers are available at reception</li>
    <li>
    Order of Priority: Allotment should be made in the following order of priority:
    <ol>
    <li>First priority - to the Officers/Officials of the Income Tax Department on duty</li>
    <li>Second priority - to the serving departmental Officers/Officials on private visit</li>
    <li>Third priority - to the Officers/Officials on duty, of other Offices who provide there guest house facility to the department</li>
    <li>Forth priority - to retired departmental Officers/Officials</li>
    <li>Fifth priority - to family members of departmental Officers/Officials</li>
    <li>Note - The Lady Officers/Officials will be given preference in allotment</li>
    </ol>
    </li>
    </ul>
    
    
    <input type="checkbox" name="accept" value="accept" required>  I Agree Terms & Conditions
&nbsp;&nbsp;&nbsp;
    
    <br>
    
    <p>
    &nbsp;&nbsp;&nbsp;
    </p>
    </div>
    <br>
   <center> <input type='submit' name='submit' class="btn btn-primary"  value='Continue Booking' ></center>
</form>


    </div>
    
    <br><br>

  <?php echo $__env->make('layouts/footer_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker1" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 3,
            maxDate : 29,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
<script>
var j = jQuery.noConflict();
    j( function() {
        j( "#datepicker2" ).datepicker({
            dateFormat: 'dd-mm-yy',
            minDate : 4,
            maxDate : 30,
            //stepMonths: 0,
            showOn: "button",
            buttonImage: "images_3/calendar.gif",
            buttonImageOnly: true,
            buttonText: "Select date"
        });
    } );
</script>
    
</body>
</html>



