<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

    Route::get('gb', function () {
        return view('gb');
    });
    
        Route::get('gb_first', function () {
            return view('gb_first');
        });
    
        
    Route::get('footer_public', function () {
        return view('footer_public');
    });
    
Auth::routes();


Route::get('/home', 'HomeController@index')->name('home');

Route::get('/gb_app_rej', 'HomeController@gbapp_rej')->name('gb_app_rej');
Route::get('/manager_home', 'HomeController@managerhome')->name('manager_home');
Route::get('/gbview_manager_cico', 'HomeController@gbviewmanager_cico')->name('gbview_manager_cico');
Route::get('/corec_gen_view', 'HomeController@corecgen_view')->name('corec_gen_view');
Route::get('/Referral_booking', 'HomeController@Referralbooking')->name('Referral_booking');
Route::get('/room_items', 'HomeController@roomitems')->name('room_items');
Route::get('/roomitem_update_view', 'HomeController@roomitemupdate_view')->name('roomitem_update_view');
Route::get('/receipt_view', 'HomeController@receiptview')->name('receipt_view');
Route::get('/manager_reports', 'HomeController@managerreports')->name('manager_reports');
Route::get('/manager_reports_view', 'HomeController@managerreports_view')->name('manager_reports_view');
Route::get('/receipt_view_first', 'HomeController@receipt_viewfirst')->name('receipt_view_first');







//Route::get('/gb', 'HomeController@gb_pub')->name('gb');

Route::post('/gb_public', 'Controller@gbpublic');
Route::post('/gb_public_second', 'Controller@gb_publicsecond');


Route::get('gb_view/{id}','HomeController@gbview');
Route::post('/gb_app_rej_adm', 'HomeController@gbapprej_adm');
Route::get('gb_view_manager/{id}','HomeController@gbview_manager');
Route::post('/gb_cico_mgr', 'HomeController@gbcico_mgr');
Route::get('co_rec_gen/{id}','HomeController@corec_gen');
Route::post('/reff_book', 'HomeController@reffbook');
Route::post('/add_item', 'HomeController@additem');
Route::get('room_item_update/{id}','HomeController@roomitem_update');
Route::post('/update_item', 'HomeController@updateitem');
Route::get('room_item_delete/{id}','HomeController@roomitem_delete');

Route::post('/gb_cico_back', 'HomeController@gb_cicoback');
Route::post('/manager_report', 'HomeController@manager_report_down');
Route::get('gb_cancel/{id}','HomeController@gbcancel');
Route::get('final_submit/{id}','HomeController@finalsubmit');
Route::get('co_rec_gen_cancel/{id}','HomeController@co_rec_gencancel');
Route::get('gb_update_gb/{id}','HomeController@gb_updategb');

Route::post('/gb_app_rej_adm_return', 'HomeController@gb_app_rej_admreturn');










